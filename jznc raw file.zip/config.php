<?php

//Redirect Links
$red_link [] = "https://www.youtube.com/embed/mH0_XpSHkZo?start=1&autoplay=1";	//Twice - More & More
$red_link [] = "https://www.youtube.com/embed/mAKsZ26SabQ?start=1&autoplay=1";	//Twice - Yes or Yes
$red_link [] = "https://www.youtube.com/embed/rRzxEiBLQCA?start=1&autoplay=1";	//Twice - Heart Shaker
$red_link [] = "https://www.youtube.com/embed/6uJf2IT2Zh8?start=1&autoplay=1";	//Red Velvet - Peek-A-Boo
$red_link [] = "https://www.youtube.com/embed/uR8Mrt1IpXg?start=1&autoplay=1";	//Red Velvet - Psycho
$red_link [] = "https://www.youtube.com/embed/fE2h3lGlOsk?start=1&autoplay=1";	//Itzy - Wannabe
$red_link [] = "https://www.youtube.com/embed/pNfTK39k55U?start=1&autoplay=1";	//Itzy - Dalla Dalla
$red_link [] = "https://www.youtube.com/embed/wTowEKjDGkU?start=1&autoplay=1";	//Itzy - Not Shy
$red_link [] = "https://www.youtube.com/embed/TgOu00Mf3kI?start=1&autoplay=1";	//IU - _ eight
$red_link [] = "https://www.youtube.com/embed/D1PvIWdJ8xo?start=1&autoplay=1";	//IU - _ Blueming
$red_link [] = "https://www.youtube.com/embed/nM0xDI5R50E?start=1&autoplay=1";	//IU - BBIBBI
$red_link [] = "https://www.youtube.com/embed/d9IxdwEFk1c?start=1&autoplay=1";	//IU - Palette
$red_link [] = "https://www.youtube.com/embed/lBYyAQ99ZFI?start=1&autoplay=1";	//SOMI - What You Waiting For
$red_link [] = "https://www.youtube.com/embed/MBdVXkSdhwU?start=1&autoplay=1";	//BTS - DNA
$red_link [] = "https://www.youtube.com/embed/EnQ9jSUCGQA?start=1&autoplay=1";	//PLAVE - Wait for you
$red_link [] = "https://www.youtube.com/embed/T_gJpnjJsnk?start=1&autoplay=1";	//[HOT] PLAVE (플레이브) - Wait for you (기다릴게) | Show! MusicCore | MBC230318방송
$red_link [] = "https://www.youtube.com/embed/I2qgmAh1em0?start=1&autoplay=1";	//PLAVE (플레이브) 'Pixel world' | Official Lyric Video
//-----------------------------------------------------------------------------------------//
?>