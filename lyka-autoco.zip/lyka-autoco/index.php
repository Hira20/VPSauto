<?php

// this is index first visit of user
if ($_SERVER['REQUEST_METHOD'] === 'GET' && !isset($_GET['pass'])) {
?>

<!DOCTYPE html>
<html>
<head>
	<title>Enter Password</title>
	<style>
		body {
			background-color: #112132;
		}

		.container {
			display: flex;
			justify-content: center;
			align-items: center;
			height: 100vh;
		}

		.card {
			border: 1px solid #525252;
			border-radius: 5px;
			box-shadow: 0px 0px 10px #000;
			max-width: 400px;
			width: 100%;
		}

		.card-body {
			background-color: #1c3044;
			border-radius: 10px;
			padding: 20px;
		}

		.card-title {
			color: white;
			text-align: center;
			margin-bottom: 20px;
		}

		form {
			margin: 0;
		}

		.form-control {
			background-color: #1c3044;
			border: none;
			border-radius: 5px;
			color: white;
			margin-bottom: 20px;
			width: 350px;
			padding: 5px;
			margin: auto; /* center horizontally */
  		display: block; /* center vertically */
		}

		.form-control:focus {
			background-color: #0e1d2c;
			color: white;
			border: none;
			outline: none;
		}

		.btn {
			background-color: #35a7ff;
			border: none;
			border-radius: 5px;
			color: black;
			cursor: pointer;
			font-weight: bold;
			padding: 10px;
			transition: background-color 0.2s ease-in-out;
			width: 100%;
		}

		.btn:hover {
			background-color: #2c83c9;
			color: black;
		}

	</style>
</head>
<body>
	<div class="container">
		<div class="card">
			<div class="card-body">
				<h4 class="card-title">Enter Password</h4>
				<form action="" method="post">
					<div class="form-group">
						<input type="password" name="pass" class="form-control text-center" placeholder="******" required>
					</div>
					<br>
					<div class="form-group">
						<button type="submit" class="btn">Submit</button>
					</div>
				</form>
			</div>
		</div>
	</div>
</body>
</html>


<?php
}

// this is the page when successfully entered the correct password & requires url
if (isset($_POST['pass']) && $_POST['pass'] === 'lyka') {
?>
<!DOCTYPE html>
<html class="loading">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">    
    <title>SPAD3 CHECKOUTER</title>
    <link href="https://fonts.googleapis.com/css?family=Muli:300,300i,400,400i,600,600i,700,700i%7CComfortaa:300,400,700" rel="stylesheet">
    <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="theme-assets/css/vendors.css">
    <link rel="stylesheet" type="text/css" href="theme-assets/css/app-lite.css">
    <link rel="stylesheet" type="text/css" href="theme-assets/css/core/menu/menu-types/vertical-menu.css">
    <link rel="stylesheet" type="text/css" href="theme-assets/css/core/colors/palette-gradient.css">
    	 <script src="https://cdn.jsdelivr.net/npm/sweetalert2@9"></script>
    	  <script>
        function updateValues(pk, cs, amount, email, xurl) {
            document.getElementById("pklive").value = pk;
            document.getElementById("cslive").value = cs;
            document.getElementById("xamount").value = amount;
            document.getElementById("xemail").value = email;
            document.getElementById("xurl").value = xurl;
        }
        function submitForm(e) {
            e.preventDefault();
            const checkoutLink = document.getElementById("checkout-link").value;

            fetch('parser.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded'
                },
                body: 'colink=' + encodeURIComponent(checkoutLink)
            })
            .then(response => response.text())
            .then(data => {
                const result = JSON.parse(data);
                updateValues(result.pklive, result.cslive, result.amount, result.email, result.xurl);
            })
            .catch(error => {
                console.error('Error:', error);
            });
        }
    </script>
  </head>
<body class="vertical-layout" style="background-color:#112132;" data-color="bg-gradient-x-purple-blue">   
  <style>
		h5,h4{
			color:white;
		}
		.text-center{
			background-color:#0e1d2c;
			border:1px solid #525252;
			border-radius:5px;
		}
		textarea{
			color:white;
			resize: none;
		}

		.text-center::placeholder{
			color:grey;
		}
		.text-center:focus{
			background-color:#0e1d2c;
		}

		textarea::-webkit-scrollbar {
  			width: 5px;
 			background-color: #112132; 
		}

		textarea::-webkit-scrollbar-thumb {
 			border-radius: 10px;
  			background-color: #2e4964; 
		}
		.lista_reprovadass{
			color:#747474;
		}
		.card-body{
			background-color: #1c3044; 
			border-radius:5px;
		}
		.text-center{
			border:none;
		}
		.badge-success,.btn-success{
			background-color: #ffe74c;
			color:black	;
			border:none;
		}
		.btn-success:hover{
			background-color: #c9b63c;
			border:none;
			color:black;
			shadow:hidden;
		}
		.aprovadas{
			background-color: #35a7ff;
			color:black	;
		}
		.badge-danger{
			background-color: #ff5964;
			color:black	;
		}
		.html body .content .content-wrapper{
			background-color:#112132;
		}

		.btn-bg-gradient {
  			background-image: linear-gradient(to right, #FF8008 0%, #FFC837  51%, #FF8008  100%);
   			 margin: 5px;
			 width:49%;
    		padding: 12px 40px;
    		text-align: center;
    		text-transform: uppercase;
    		transition: 0.5s;
    		background-size: 200% auto;
    		color: white;            
    		box-shadow: 0 0 20px #eee;
    		border-radius: 5px;
    		display: block;
			-webkit-box-shadow: 0 0 0 0 #514a9d;
  		}

  		.btn-bg-gradient:hover {
   			background-position: right center; /* change the direction of the change here */
    		color: #fff;
    		text-decoration: none;
  		}

		  .btn-bg-gradient-x {
			background-image: linear-gradient(to right, #ee0979 0%, #ff6a00  51%, #ee0979  100%);
            margin: 5px;
            padding: 12px 45px;
			
            text-align: center;
            text-transform: uppercase;
            transition: 0.5s;
            background-size: 200% auto;
            color: white;            
            box-shadow: 0 0 20px #eee;
            border-radius: 5px;
            display: block;
			-webkit-box-shadow: 0 0 0 0 #514a9d;
  		}

  		.btn-bg-gradient-x:hover {
			background-position: right center; /* change the direction of the change here */
            color: #fff;
            text-decoration: none;
  		}

		  .statusbar{
			height:320px;
			padding-top:50px;
		  }
		  .hr-statusbar{
			border:none;
			height:1px;
			background-color:#3c5c7c;
		  }
		  
		  option { 
    /* Whatever color  you want */
    background-color: #112132;
	color: white;
	}
	</style>
	
    <div class="app-content content" style="display:block;">
      <div class="content-wrapper" style="background-color:#112132;">
          
	  <div class="text-center" style="background-color:#112132;">
<h4 class="mb-2"><strong>LYKA CHECKOUTER</strong></h4>
<div class="form-group">
HITS: <span class="badge badge-success charge">0</span>
LIVE: <span class="badge badge-success aprovadas"> 0</span>
DEAD: <span class="badge badge-danger reprovadas"> 0</span>
TOTAL: <span class="badge badge-primary carregadas"> 0</span>
LIMIT: <span class="badge badge-secondary"> 100</span><br>
</div>
	  </div>
	         
  <div class="content-body">
  	<div class="mt-2"></div>
	<div class="row">
		<div class="col-md-12">
			<div class="card">
				<div class="card-body text-center">
					<textarea rows="6" class="form-control text-center form-checker mb-2" placeholder="PUT YOUR CARD LIST HERE :>"></textarea>

					<div>
						 <form onsubmit="submitForm(event)">
        <input type="text" style="background-color:#112132;" class="form-control text-center" id="checkout-link" name="checkoutlink" style="width: 100%;" placeholder="Paste your checkout link here">
        <button class="btn btn-play btn-glow btn-bg-gradient-x-blue-cyan text-white" style="width: 100%; float: left;" type="submit">Parse now</button>
    </form> 
					</div>
					<br><br>
					<div class="input-group mb-1">
					<input type="text" style="background-color:#112132;" class="form-control" id="cslive" placeholder="cs_live_xxx" name="cslive" disabled>&nbsp;       
					<input type="text" style="background-color:#112132;" class="form-control" id="pklive" placeholder="pk_live_xxx" name="pklive" disabled>
                    </div>
                    
                    <div class="input-group mb-1">
					<input type="number" style="background-color:#112132;" class="form-control" id="xamount" placeholder="AMOUNT" name="xamount">&nbsp;
					<input type="text" style="background-color:#112132;" class="form-control" id="xemail" placeholder="EMAIL" name="xemail">
										</div>
					<div class="input-group mb-1">
									 <input type="hidden" style="background-color:#112132; width: 25px;" class="form-control" id="xurl" placeholder="Support URL" name="xurl">
					<input type="text" style="background-color:#112132; width: 25px;" class="form-control" id="ip" placeholder="ProxyIP:Port" name="ip" autocomplete="off">&nbsp;
			<input type="text" style="background-color:#112132;width: 25px;" class="form-control" id="hydra" placeholder="Username:Password" name="hydra" autocomplete="off">
					</div>


					<button class="btn btn-play btn-glow btn-bg-gradient-x-blue-cyan text-white" style="width: 49%; float: left;"><i class="fa fa-play"></i>START</button>
					<button class="btn btn-stop btn-glow btn-bg-gradient-x-red-pink text-white" style="width: 49%; float: right;" disabled><i class="fa fa-stop"></i>STOP</button>
					
				</div>
			</div>
		</div>

            		<div class="col-xl-12">
			<div class="card">
				<div class="card-body">
					<div class="float-right">
						<button type="show" class="btn btn-primary btn-sm show-charge"><i class="fa fa-eye-slash"></i></button>
					<button class="btn btn-success btn-sm btn-copy1"><i class="fa fa-copy"></i></button>					
					</div>
					<h4 class="card-title mb-1"><i class="fa fa-check-circle text-success"></i> SUCCESS HITS <span class="badge badge-success charge">0</span></h4>					
			<div id='cards_charge'></div>
				</div>				
			</div>
		</div>
		<div class="col-xl-12">
			<div class="card">
				<div class="card-body">
					<div class="float-right">
						<button type="show" class="btn btn-primary btn-sm show-lives"><i class="fa fa-eye-slash"></i></button>
					<button class="btn btn-success btn-sm btn-copy"><i class="fa fa-copy"></i></button>					
					</div>
					<h4 class="card-title mb-1"><i class="fa fa-check text-success"></i> JUST LIVE BINS <span class="badge badge-success aprovadas">0</span></h4>					
			<div id='cards_aprovadas'></div>
				</div>				
			</div>
		</div>
		<div class="col-xl-12">
			<div class="card">
				<div class="card-body">
					<div class="float-right">
						<button type='hidden' class="btn btn-primary btn-sm show-dies"><i class="fa fa-eye"></i></button>
					<button class="btn btn-danger btn-sm btn-trash"><i class="fa fa-trash"></i></button>					
					</div>
					<h4 class="card-title mb-1"><i class="fa fa-times text-danger"></i> TRASHED TXs <span class="badge badge-danger reprovadas">0</span></h4>		
						<div style='display: none;' id='cards_reprovadas'></div>
				</div>				
			</div>
		</div>
		
</section>
        </div>
      </div>
    </div>
 
    <script src="theme-assets/js/core/libraries/jquery.min.js" type="text/javascript"></script>

<script>
$(document).ready(function(){
Swal.fire({
  title: "EASY CHECKOUTER",
  //text: "Click here to join my telegram channel",
  icon: "success",
  showCancelButton: false,
  confirmButtonClass: "btn btn-success",
  cancelButtonClass: "btn btn-link",
  //confirmButtonText: "Click here to join my channel",
  //cancelButtonText: "Proceed",
  buttonsStyling: false,
  reverseButtons: true,
  allowOutsideClick: false,
  //preConfirm: () => {
  //  window.location.href = "https://t.me/yourtelegramchannel";
  //}
}).then((result) => {
  if (result.dismiss === Swal.DismissReason.cancel) {
    Swal.fire({
      title: "Welcome",
      text: "Paste the checkout link to start",
      icon: "success",
      confirmButtonClass: "btn btn-primary",
      buttonsStyling: false,
    });
  }
});

$('.show-charge').click(function(){
var type = $('.show-charge').attr('type');
$('#cards_charge').slideToggle();
if(type == 'show'){
$('.show-charge').html('<i class="fa fa-eye"></i>');
$('.show-charge').attr('type', 'hidden');
}else{
$('.show-charge').html('<i class="fa fa-eye-slash"></i>');
$('.show-charge').attr('type', 'show');
}});
$('.show-lives').click(function(){
var type = $('.show-lives').attr('type');
$('#cards_aprovadas').slideToggle();
if(type == 'show'){
$('.show-lives').html('<i class="fa fa-eye"></i>');
$('.show-lives').attr('type', 'hidden');
}else{
$('.show-lives').html('<i class="fa fa-eye-slash"></i>');
$('.show-lives').attr('type', 'show');
}});
$('.show-dies').click(function(){
var type = $('.show-dies').attr('type');
$('#cards_reprovadas').slideToggle();
if(type == 'show'){
$('.show-dies').html('<i class="fa fa-eye"></i>');
$('.show-dies').attr('type', 'hidden');
}else{
$('.show-dies').html('<i class="fa fa-eye-slash"></i>');
$('.show-dies').attr('type', 'show');
}});
$('.btn-trash').click(function(){
	Swal.fire({title: 'REMOVE CC DEAD SUCCESS', icon: 'success', showConfirmButton: false, toast: true, position: 'top-end', timer: 3000});
$('#cards_reprovadas').text('');
});
$('.btn-copy1').click(function(){
	Swal.fire({title: 'COPY CC CHARGED SUCCESS', icon: 'success', showConfirmButton: false, toast: true, position: 'top-end', timer: 3000});
var cards_charge = document.getElementById('cards_charge').innerText;
var textarea = document.createElement("textarea");
textarea.value = cards_charge;
document.body.appendChild(textarea); 
textarea.select(); 
document.execCommand('copy');           document.body.removeChild(textarea); 
});

$('.btn-copy').click(function(){
	Swal.fire({title: 'COPY CC LIVE SUCCESS', icon: 'success', showConfirmButton: false, toast: true, position: 'top-end', timer: 3000});
var cards_lives = document.getElementById('cards_aprovadas').innerText;
var textarea = document.createElement("textarea");
textarea.value = cards_lives;
document.body.appendChild(textarea); 
textarea.select(); 
document.execCommand('copy');           
document.body.removeChild(textarea); 
});
$('.btn-play').click(function(){
var cards = $('.form-checker').val().trim();
var array = cards.split('\n');
var pklive = $("#pklive").val().trim();
var cslive = $("#cslive").val().trim();
var xamount = $("#xamount").val().trim();
var xemail = $("#xemail").val().trim();
var xurl = $("#xurl").val().trim();
var charge = 0, lives = 0, dies = 0, testadas = 0, txt = '';
if(!cards){
	Swal.fire({title: 'Wheres your card?? please add a card!!', icon: 'error', showConfirmButton: false, toast: true, position: 'top-end', timer: 3000});
	return false;
}
if(!pklive){
	Swal.fire({title: 'Wheres your pklive?? please add a pklive!!', icon: 'error', showConfirmButton: false, toast: true, position: 'top-end', timer: 3000});
	return false;
}
if(!cslive){
	Swal.fire({title: 'Wheres your cslive?? please add a cslive!!', icon: 'error', showConfirmButton: false, toast: true, position: 'top-end', timer: 3000});
	return false;
}
if(!xamount){
	Swal.fire({title: 'Wheres the amount?? please add a amount!!', icon: 'error', showConfirmButton: false, toast: true, position: 'top-end', timer: 3000});
	return false;
}
if(!xemail){
	Swal.fire({title: 'Wheres the email?? please add a email!!', icon: 'error', showConfirmButton: false, toast: true, position: 'top-end', timer: 3000});
	return false;
}
Swal.fire({title: 'Please wait for the card to be processed !!', icon: 'success', showConfirmButton: false, toast: true, position: 'top-end', timer: 3000});
var line = array.filter(function(value){
if(value.trim() !== ""){
	txt += value.trim() + '\n';
	return value.trim();
}
});

/*
var line = array.filter(function(value){
return(value.trim() !== "");
});
*/

var total = line.length;


/*
line.forEach(function(value){
txt += value + '\n';
});
*/

$('.form-checker').val(txt.trim());
// ảo ma hả, đừng lấy code chứ !!
if(total > 100){
  Swal.fire({title: 'CHECK ONLY 100 CC', icon: 'warning', showConfirmButton: false, toast: true, position: 'top-end', timer: 3000});
  return false;
}

$('.carregadas').text(total);
$('.btn-play').attr('disabled', true);
$('.btn-stop').attr('disabled', true);

line.every(function(data, index){
setTimeout(
function() {
var callBack = $.ajax({
  url: 'chk.php?cards=' + data + '&cslive=' + cslive + '&pklive=' + pklive + '&xamount=' + xamount + '&xemail=' + xemail + '&xurl=' + xurl + '&referrer=Auth',
  success: function(retorno){
    if(retorno.indexOf("#OWSHETTCHARGED") >= 0){
      Swal.fire({title: 'OWSHETT TAENG MALAGKET!? YOU HIT IT BRUHH..\nSKRRRTT!!!..', icon: 'success', showConfirmButton: false, toast: true, position: 'top-end', timer: 3000});
      $('#cards_charge').append(retorno);
      removelinha();
      charge = charge +1;
      }
      else if(retorno.indexOf("#LIVE") >= 0){
      Swal.fire({title: '+1 LIVE CC', icon: 'success', showConfirmButton: false, toast: true, position: 'top-end', timer: 3000});
      $('#cards_aprovadas').append(retorno);
      removelinha();
      lives = lives +1;
        }else{
      $('#cards_reprovadas').append(retorno);
      removelinha();
      dies = dies +1;
    }
    testadas = charge + lives + dies;
      $('.charge').text(charge);
    $('.aprovadas').text(lives);
    $('.reprovadas').text(dies);
    $('.testadas').text(testadas);
    
    if(testadas == total){
      Swal.fire({title: 'HAVE BEEN DISPOSED', icon: 'success', showConfirmButton: false, toast: true, position: 'top-end', timer: 3000});
      $('.btn-play').attr('disabled', false);
      $('.btn-stop').attr('disabled', false);
    }
        }
      });
    }, 3000 * index);
    return true;
    });
  });
});
function removelinha() {
var lines = $('.form-checker').val().split('\n');
lines.splice(0, 1);
$('.form-checker').val(lines.join("\n"));
}
</script>

  </body>
</html>
<?php
}
?>