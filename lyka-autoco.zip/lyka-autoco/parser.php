    <?php
    error_reporting(0);
    $randomString = substr(str_shuffle(md5(time())), 0, 5);
      if (isset($_POST["colink"])) {
        $colink = $_POST["colink"];
        $obfuscatedPK = urldecode(explode("#", $colink)[1]);
        $decoded = base64_decode($obfuscatedPK);
        $deobfed = "";
        foreach(str_split($decoded) as $c) {
            $deobfed .= chr(5 ^ ord($c));
        }
        $shuroap = json_decode($deobfed, true);
        $pklive = $shuroap["apiKey"];
        $headers = array(
            "Host: api.stripe.com",
            "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/111.0",
            "Accept: application/json",
            "Referer: https://checkout.stripe.com/",
            "Content-Type: application/x-www-form-urlencoded",
            "Origin: https://checkout.stripe.com",
        );
        $post_data = array(
            "key" => $pklive,
            "eid" => "NA",
            "browser_locale" => "en-US",
            "redirect_type" => "stripe_js"
        );
        $post_data_str = http_build_query($post_data);
        $cslive = end(explode("/", explode("#", $colink)[0]));
        $url = "https://api.stripe.com/v1/payment_pages/".$cslive."/init";
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $post_data_str);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $response = curl_exec($ch);
        curl_close($ch);

        // Parse the response JSON and extract the data
        $response_data = json_decode($response, true);
        if (isset($response_data["message"]) || $response_data["message"] === "This Checkout Session is no longer active." || strpos($response, 'No such payment_page')) {
        die("Error: This Checkout Session is no longer active.");
        }
        if (isset($response_data["line_item_group"]["total"])) {
            $xamount = $response_data["line_item_group"]["total"];
        } elseif (isset($response_data["invoice"]["total"])) {
            $xamount = $response_data["invoice"]["total"];
        } else {
            $xamount = "Please retry submitting checkout link";
        }
        if (isset($response_data["account_settings"]["support_url"])) {
            $xurl = $response_data["account_settings"]["support_url"];
        }  else {
            $xurl = "Invalid Checkout Link";
        }
        if (isset($response_data["customer"]["email"])) {
            $xemail = $response_data["customer"]["email"];
            $xemail = urlencode($xemail);
        } elseif (isset($response_data["customer_email"])) {
            $xemail = $response_data["customer_email"];
            $xemail = urlencode($xemail);
        } else {
            $xemail = "lykachk_random$randomString@gmail.com";
        }
}
echo '{"pklive":"'.$pklive.'","cslive":"'.$cslive.'","amount":"'.$xamount.'","email":"'.$xemail.'","xurl":"'.$xurl.'"}';
?>