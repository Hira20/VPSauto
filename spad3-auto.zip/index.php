<html>
  <head>
    <title>SPAD3</title>
  </head>
  <body>
    <?php
    echo "To start, just <a href='spad3-auto/'><font color='blue'>click here</font></a>.";
    ?>
  </body>
</html>
